import os,pathlib,subprocess,time,json
p=pathlib.Path.cwd();env={'PATH':os.environ['PATH'],'TMPDIR':'/tmp','npm_config_cache':'/tmp/cetld-npm-cache'};argv=['npm','run','check:release','--','--shards=4'];start=time.time()
(p/'work/r4/gate-command.json').write_text(json.dumps({'cwd':str(p),'argv':argv,'env':env,'started':start},indent=2)+'\n')
with (p/'work/r4/gate.log').open('w') as log:code=subprocess.call(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'work/r4/gate.exit').write_text(str(code)+'\n');(p/'work/r4/gate-duration.json').write_text(json.dumps({'seconds':time.time()-start,'exit':code})+'\n');print('ROUND4_RELEASE_EXIT',code,flush=True)
raise SystemExit(code)
