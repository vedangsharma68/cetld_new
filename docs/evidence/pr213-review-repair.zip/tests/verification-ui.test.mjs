import {bookkeepingSyncLabel,bookkeepingSyncError,isUnconfiguredBookkeeping,showBookkeepingSyncError} from '../invoice/bookkeeping-client.mjs';
// Existing own-number proof policy; no copied personal contact literal.
import {REMINDER_PROOF_PHONE as QA_POLICY_PHONE} from '../automation/whatsapp/reminder-proof.mjs';
import {receivableBalanceLabel} from '../invoice/receivables.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createOwnerTemplateTestUI,zohoDiscoveryView,ownerTemplateCheckView} from '../verification-ui.mjs';

const workspaceId='9a83b58d-6b02-4b17-8de5-c67136f26434',userId='40ff343c-4334-4aec-b49a-ca772f0cf8ad',invoiceId='f86e28bd-16a8-4c83-a03d-05302f7f3ff6';
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const preview={test:true,audience:'owner',workspaceId,ownerId:userId,invoiceId,recipient:QA_POLICY_PHONE,
  template:{name:'cetld_invoice_update_v3',language:{code:'en'}},text:'Hi, this is CETLD test. Invoice TEST ONLY - INV-2026-6771 for owner test only has an update.',previewToken:'fixture-preview-secret'};
function setup({reply=preview,request}={}){
  const state={demo:false,user:{id:userId},workspace:{id:workspaceId,owner_id:userId},invoices:[{id:invoiceId,total:140,paid:40,paused:true}]};
  const snapshots=[],errors=[],toasts=[],calls=[];let head={};
  const dialog={open:false,querySelector(selector){return selector==='.dialog-head'?head:null;}};
  const ui=createOwnerTemplateTestUI({state,escape,dialog:()=>dialog,button:(action,label)=>`<button data-action="${action}">${label}</button>`,
    openDialog(title,body){snapshots.push({title,body});head={};dialog.open=true;},showError(_dialog,error){errors.push(error.message);},toast:message=>toasts.push(message),
    request:async(id,options)=>{calls.push({id,options});return request?request(id,options):options.method==='POST'?{status:'accepted'}:reply;}});
  return {state,ui,snapshots,errors,toasts,calls,dialog,control:()=>({disabled:false,dataset:{},textContent:'',setAttribute(key,value){this[key]=value;}})};
}

test('sanitized template-check fields are visible in terminal failure and all text is escaped',async()=>{
  const check={issue:'footer_text',templateName:'cetld_invoice_update_v3',
    expected:{status:'APPROVED',category:'UTILITY',language:'en',parameterFormat:'POSITIONAL',parameterFormatOptional:true,
      components:[{type:'BODY',text:'Approved {{1}} {{2}} {{3}}'}]},
    observed:{status:'PAUSED',category:'MARKETING',language:'en',parameterFormat:'NAMED',components:[{type:'BODY',text:'Approved {{1}} {{2}} {{3}}'},{type:'FOOTER',text:'Synthetic <footer>'}]}};
  const f=setup({request:async()=>{throw Object.assign(Error('APPROVED_TEST_TEMPLATE_MISMATCH'),{templateCheck:check});}});
  await f.ui.review(f.control(),invoiceId);
  const html=f.snapshots.at(-1).body;
  for(const value of ['Template check','footer_text','Expected','Observed','Approval status','APPROVED','PAUSED','Category','UTILITY','MARKETING',
    'Language','en','Parameter format','POSITIONAL','NAMED','BODY','FOOTER','Approved {{1}} {{2}} {{3}}','may be omitted'])assert.ok(html.includes(value),value);
  assert.match(html,/Synthetic &lt;footer&gt;/);assert.doesNotMatch(html,/Synthetic <footer>|aria-busy="true"/);
  const hostile=structuredClone(check);hostile.issue=hostile.templateName=hostile.expected.status=hostile.observed.status='<img src=x>';
  hostile.expected.components[0]={type:'<BODY>',text:'<script>'};
  const escaped=ownerTemplateCheckView(hostile,escape);assert.doesNotMatch(escaped,/<img|<BODY>|<script>/);assert.match(escaped,/&lt;script&gt;/);
  assert.equal(f.calls.filter(call=>call.options.method==='POST').length,0);await assert.rejects(f.ui.send(f.control()));
  assert.equal(ownerTemplateCheckView(null,escape),'');
});

for(const message of ['APPROVED_TEST_TEMPLATE_MISMATCH','WHATSAPP_TEMPLATE_READ_UNAVAILABLE','Preview timed out. No message was sent.'])
test(`terminal preview error clears busy/loading text without enabling send: ${message}`,async()=>{
  const f=setup({request:async()=>{throw Error(message);}}),before=structuredClone(f.state.invoices);
  const control=f.control();await f.ui.review(control,invoiceId);
  assert.match(f.snapshots[0].body,/aria-busy="true"/);
  const html=f.snapshots.at(-1).body;
  assert.match(html,/role="status"[^>]*>Preview unavailable\. No message was sent\.</);
  assert.doesNotMatch(html,/Preparing|aria-busy="true"/);assert.match(html,/owner-template-test-review/);
  assert.deepEqual(f.errors,[message]);assert.equal(control.disabled,false);
  assert.ok(f.snapshots.every(snapshot=>!snapshot.body.includes('owner-template-test-send')));
  await assert.rejects(f.ui.send(f.control()),/fresh owner test preview/);
  assert.equal(f.calls.length,1);assert.equal(f.calls.filter(call=>call.options.method==='POST').length,0);
  assert.deepEqual(f.state.invoices,before);
});

test('visible owner review shows exact recipient/message and does not render tokens or send',async()=>{
  const f=setup(),before=structuredClone(f.state.invoices);assert.equal(f.ui.canReview(f.state.invoices[0]),true);
  await f.ui.review(f.control(),invoiceId);assert.equal(f.snapshots.length,2);assert.equal(f.calls.length,1);
  const html=f.snapshots[1].body;assert.ok(html.includes(preview.text));assert.ok(html.includes(preview.recipient));
  assert.ok(html.includes('Send one owner test'));assert.ok(!html.includes(preview.previewToken));assert.ok(!html.includes('approved-template-test'));
  assert.notEqual(f.calls[0].options.method,'POST');assert.deepEqual(f.errors,[]);assert.deepEqual(f.state.invoices,before);
});

test('visible send consumes one reviewed preview, remains disabled and reports acceptance separately from delivery',async()=>{
  const f=setup(),control=f.control();await f.ui.review(f.control(),invoiceId);await f.ui.send(control);
  assert.equal(control.disabled,true);assert.equal(control.dataset.keepDisabled,'true');assert.equal(control.textContent,'Accepted by Meta');
  assert.equal(control['aria-label'],'Accepted by Meta');
  const posts=f.calls.filter(c=>c.options.method==='POST');assert.equal(posts.length,1);assert.equal(posts[0].options.previewToken,preview.previewToken);
  assert.match(f.toasts[0],/accepted.*Conversations.*delivery status/i);
  await assert.rejects(f.ui.send(f.control()),/fresh owner test preview/);assert.equal(f.calls.filter(c=>c.options.method==='POST').length,1);
});

for(const [deliveryStatus,label] of [['delivered','Already delivered'],['read','Already read'],['sent','Already sent'],
  ['accepted','Already accepted by Meta'],['failed','Previous dispatch failed'],['blocked','Previous dispatch blocked'],
  ['pending','Previous dispatch unconfirmed'],['unknown','Previous dispatch unconfirmed']])
test(`existing ${deliveryStatus} receipt never offers or repeats a send or overstates delivery`,async()=>{
  const existing={test:true,audience:'owner',workspaceId,ownerId:userId,invoiceId,recipient:preview.recipient,status:'existing',deliveryStatus};
  const f=setup({reply:existing}),before=structuredClone(f.state.invoices);
  await f.ui.review(f.control(),invoiceId);
  const html=f.snapshots.at(-1).body;assert.ok(html.includes(label));assert.match(html,/No new message was sent/);
  assert.doesNotMatch(html,/data-action="owner-template-test-send"|Preparing owner test preview/);
  if(!['delivered','read'].includes(deliveryStatus))assert.doesNotMatch(html,/Already delivered|Already read/);
  await assert.rejects(f.ui.send(f.control()),/fresh owner test preview/);
  assert.equal(f.calls.length,1);assert.deepEqual(f.state.invoices,before);
  const race=setup({request:async(_id,options)=>options.method==='POST'?existing:preview});
  await race.ui.review(race.control(),invoiceId);const control=race.control();await race.ui.send(control);
  assert.equal(control.textContent,label);assert.equal(control.disabled,true);assert.equal(control.dataset.keepDisabled,'true');
  assert.match(race.toasts[0],/No new message was sent/);
  await assert.rejects(race.ui.send(race.control()),/fresh owner test preview/);
  assert.equal(race.calls.filter(c=>c.options.method==='POST').length,1);
});

test('a foreign existing receipt cannot expose its status or a send action',async()=>{
  const f=setup({reply:{...preview,status:'existing',deliveryStatus:'delivered',recipient:'+919818685252'}});
  await f.ui.review(f.control(),invoiceId);
  assert.doesNotMatch(f.snapshots.at(-1).body,/Already delivered|data-action="owner-template-test-send"/);
  assert.equal(f.errors.length,1);
});

for(const result of ['unknown','network-error'])test(`visible ${result} result never retries or reenables send`,async()=>{
  const f=setup({request:async(_id,options)=>{if(options.method!=='POST')return preview;if(result==='network-error')throw Error('Fixture network unavailable');return {status:'unknown'};}});
  await f.ui.review(f.control(),invoiceId);const control=f.control();await f.ui.send(control);
  assert.equal(control.disabled,true);assert.equal(control.textContent,'Result unconfirmed');
  await assert.rejects(f.ui.send(f.control()),/fresh owner test preview/);assert.equal(f.calls.filter(c=>c.options.method==='POST').length,1);
});

for(const change of ['demo','foreign-user','foreign-workspace','foreign-owner','different-invoice'])test(`owner test visibility and review reject ${change}`,async()=>{
  const f=setup();if(change==='demo')f.state.demo=true;if(change==='foreign-user')f.state.user.id='other';
  if(change==='foreign-workspace')f.state.workspace.id='other';if(change==='foreign-owner')f.state.workspace.owner_id='other';
  if(change==='different-invoice')f.state.invoices[0].id='other';
  assert.equal(f.ui.canReview(f.state.invoices[0]),false);await assert.rejects(f.ui.review(f.control(),invoiceId));assert.equal(f.calls.length,0);
});

for(const patch of [{recipient:'+919818685252'},{workspaceId:'other'},{audience:'customer'},{test:false},{template:{name:'other',language:{code:'en'}}}])
test(`mismatched server preview cannot expose send action ${JSON.stringify(patch)}`,async()=>{
  const f=setup({reply:{...preview,...patch}});await f.ui.review(f.control(),invoiceId);
  assert.match(f.snapshots.at(-1).body,/Preview unavailable/);
  assert.ok(f.snapshots.every(snapshot=>!snapshot.body.includes('data-action="owner-template-test-send"')));
  assert.equal(f.errors.length,1);
  await assert.rejects(f.ui.send(f.control()));assert.equal(f.calls.length,1);
});

for(const change of ['workspace','user','closed-dialog'])test(`late preview after ${change} change is discarded`,async()=>{
  let release;const pending=new Promise(resolve=>{release=resolve;});const f=setup({request:async()=>pending});
  const work=f.ui.review(f.control(),invoiceId);if(change==='workspace')f.state.workspace.id='other';if(change==='user')f.state.user.id='other';if(change==='closed-dialog')f.dialog.open=false;
  release(preview);await work;assert.equal(f.snapshots.length,1);await assert.rejects(f.ui.send(f.control()));assert.equal(f.calls.length,1);
});

test('account switching after preview blocks send before the application request helper',async()=>{
  const f=setup();await f.ui.review(f.control(),invoiceId);f.state.workspace.id='other';await assert.rejects(f.ui.send(f.control()));assert.equal(f.calls.length,1);
});

test('rejected owner preview replaces loading with a recoverable error and never exposes send',async()=>{
  const f=setup({request:async()=>{throw Error('APPROVED_TEST_TEMPLATE_MISMATCH');}}),control=f.control();
  await f.ui.review(control,invoiceId);
  const html=f.snapshots.at(-1).body;
  assert.doesNotMatch(html,/Preparing owner test preview|aria-busy="true"/);
  assert.match(html,/Preview unavailable/);
  assert.match(html,/data-action="owner-template-test-review"/);
  assert.doesNotMatch(html,/data-action="owner-template-test-send"/);
  assert.equal(control.disabled,false);
  assert.equal(f.errors.length,1);
  await assert.rejects(f.ui.send(f.control()),/fresh owner test preview/);
});

test('owner review renders the no-footer message',async()=>{
  const f=setup({reply:{...preview,footer:null}});
  await f.ui.review(f.control(),invoiceId);
  assert.doesNotMatch(f.snapshots.at(-1).body,/Reply STOP|opt.out/i);
  assert.equal(f.errors.length,0);
});

test('Zoho diagnostics distinguish empty and error results, escape data and contain no connect/sync controls',()=>{
  for(const status of ['available','empty','error']){
    const html=zohoDiscoveryView({status,organizationCount:status==='error'?null:0,providerCode:'<img src=x onerror=alert(1)>',httpStatus:200},escape);
    assert.ok(html.includes('Organization check'));assert.ok(html.includes('HTTP status'));assert.ok(!html.includes('<img'));
    assert.ok(html.includes('&lt;img'));assert.ok(!html.includes('data-action='));
  }
  assert.equal(zohoDiscoveryView(null,escape),'');assert.equal(zohoDiscoveryView({status:'forged'},escape),'');
});

test('app routes visible owner controls through existing session helper and Zoho check through status only',async()=>{
  const source=await readFile(new URL('../app.js',import.meta.url),'utf8');
  assert.match(source,/ownerTemplateTestUI\.canReview\(x\)\?button\('owner-template-test-review','Review owner test'/);
  assert.match(source,/if\(action==='owner-template-test-review'\)return await ownerTemplateTestUI\.review\(b,id\)/);
  assert.match(source,/if\(action==='owner-template-test-send'\)return await ownerTemplateTestUI\.send\(b\)/);
  assert.match(source,/request:\(id,options=\{\}\)=>whatsappTestRequest\(id,\{\.\.\.options,action:'owner-template-test'\}\)/);
  const check=source.slice(source.indexOf("if(action==='check-zoho-status')"),source.indexOf("if(action==='select-zoho-organization')"));
  assert.match(check,/accountingRequest\('status'\)/);assert.doesNotMatch(check,/sync|start|select-organization|loadData|refreshZohoLedger/);
  assert.match(source,/zohoDiscoveryView\(status\.organizationDiscovery,escape\)/);
});

test('application helper uses its existing auth session internally and exact endpoint action/preview header',async()=>{
  const source=await readFile(new URL('../app.js',import.meta.url),'utf8');
  const code=source.slice(source.indexOf('async function whatsappTestRequest('),source.indexOf('const ownerTemplateTestUI='));
  const calls=[],state={workspace:{id:workspaceId},invoices:[{id:invoiceId}]};
  const context={state,URL,location:{origin:'https://fixture.test'},accessToken:async()=>'fixture-app-session',readyReminderPreviewToken:()=>null,
    ownerTemplateTestUI:{canReview:()=>true},fetch:async(url,options)=>{calls.push({url:String(url),options});return Response.json(options.method==='POST'?{status:'accepted'}:preview);}};
  vm.runInNewContext(code+';globalThis.request=whatsappTestRequest;',context);
  await context.request(invoiceId,{action:'owner-template-test'});await context.request(invoiceId,{action:'owner-template-test',method:'POST',previewToken:preview.previewToken});
  assert.ok(calls[0].url.includes('action=owner-template-test'));assert.equal(calls[0].options.headers.Authorization,'Bearer fixture-app-session');
  assert.deepEqual(JSON.parse(calls[1].options.body),{workspaceId,invoiceId,action:'owner-template-test'});
  assert.equal(calls[1].options.headers['X-WhatsApp-Test-Preview'],preview.previewToken);assert.equal(calls.length,2);
});

for(const change of ['ordinary-owner','foreign-user','foreign-workspace','foreign-owner','different-invoice','demo','eligible'])
test(`repeated invoice drawer opens gate test-preview requests with button eligibility: ${change}`,async()=>{
  const source=await readFile(new URL('../app.js',import.meta.url),'utf8'),f=setup();
  Object.assign(f.state.invoices[0],{client:'Fixture customer',number:'INV-1',invoice_direction:'receivable'});
  if(change==='ordinary-owner'){
    f.state.user.id=f.state.workspace.owner_id='ordinary-owner';f.state.workspace.id='ordinary-workspace';
  }
  if(change==='foreign-user')f.state.user.id='other';
  if(change==='foreign-workspace')f.state.workspace.id='other';
  if(change==='foreign-owner')f.state.workspace.owner_id='other';
  if(change==='different-invoice')f.state.invoices[0].id='other';
  if(change==='demo')f.state.demo=true;
  const calls=[],drawers=[],insertions=[],context={
    state:f.state,ownerTemplateTestUI:f.ui,URL,location:{origin:'https://fixture.test'},
    readyReminderPreviewToken:()=>null,accessToken:async()=>'fixture-session',
    fetch:async(url,options)=>{calls.push({url:String(url),method:options.method});return Response.json(preview);},
    openDialog:(_title,body)=>drawers.push(body),escape,status:()=> 'Open',remaining:()=>10000,
    receivableBalanceLabel,terminalInvoice:()=>false,activeException:()=>null,followupStage:()=>['Draft',''],
    money:()=>'$100',tag:()=>'',day:()=>'',deliveryState:()=>'',invoiceBusinessDetails:()=>'',
    bookkeepingSyncLabel,bookkeepingSyncError,isUnconfiguredBookkeeping,showBookkeepingSyncError,customFieldsView:()=>'',icon:()=>'',canRetryInvoiceSync:()=>false,isExternallyManagedInvoice:()=>false,
    button:(action,label)=>`<button data-action="${action}">${label}</button>`,
    $:()=>({open:true,querySelector:()=>({insertAdjacentHTML:(_position,html)=>insertions.push(html)})}),
  };
  const helper=source.slice(source.indexOf('async function whatsappTestRequest('),source.indexOf('const ownerTemplateTestUI='));
  const drawer=source.slice(source.indexOf('function detail(id){'),source.indexOf('function customerReminderToneForm('));
  vm.runInNewContext(helper+drawer+';globalThis.openInvoice=detail;',context);
  const eligible=f.ui.canReview(f.state.invoices[0]);assert.equal(eligible,change==='eligible');
  for(let i=0;i<3;i++){
    context.openInvoice(f.state.invoices[0].id);
    await new Promise(resolve=>setImmediate(resolve));
  }
  assert.equal(drawers.length,3);
  for(const html of drawers)assert.equal(html.includes('data-action="owner-template-test-review"'),eligible);
  assert.equal(calls.length,eligible?3:0);
  assert.equal(insertions.length,eligible?3:0);
  for(const call of calls){
    const url=new URL(call.url);assert.equal(url.pathname,'/api/whatsapp-test-send');
    assert.equal(url.searchParams.get('workspaceId'),workspaceId);assert.equal(url.searchParams.get('invoiceId'),invoiceId);
    assert.equal(call.method,'GET');
  }
});
