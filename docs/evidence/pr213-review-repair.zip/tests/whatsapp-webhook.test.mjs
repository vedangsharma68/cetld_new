import test from 'node:test';
import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { createHmac } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
import { createWhatsAppWebhookHandler, readRawBody, verifyMetaSignature } from '../automation/whatsapp/webhook.mjs';
import { createInboundRuntime, SupabaseInboundInbox, isOptOut, parseMetaMessages } from '../automation/whatsapp/cloud-inbound.mjs';
import { neutralText } from '../automation/whatsapp/cloud-outbound.mjs';
import {createOwnerReplyStore} from '../automation/whatsapp/owner-reply-store.mjs';
import {createOwnerActionButtons} from '../automation/whatsapp/owner-action-buttons.mjs';
import { answerWorkspaceQuestion } from '../ai/assistant.mjs';
import {installVerifiedOwnerRpc} from './fixtures/verified-owner-rpc.mjs';

const env = { WHATSAPP_VERIFY_TOKEN: 'verify-secret', WHATSAPP_APP_SECRET: 'app-secret',
  WHATSAPP_PHONE_NUMBER_ID: '123456789', WHATSAPP_WABA_ID: '987654321', CRON_SECRET: 'cron-secret' };
const meta = (messages) => ({ object: 'whatsapp_business_account', entry: [{ id: env.WHATSAPP_WABA_ID, changes: [{ field: 'messages', value: {
  metadata: { phone_number_id: env.WHATSAPP_PHONE_NUMBER_ID }, messages,
} }] }] });
const message = (id, body = 'Hello') => ({ id, from: '12025550101', timestamp: String(Math.floor(Date.now() / 1000)),
  type: 'text', text: { body } });
function withEmptyVerifiedOwnerRpc(supabase,phone){return installVerifiedOwnerRpc(supabase,()=>({}),{expectedPhone:phone});}
function response() {
  return { statusCode: 200, headers: {}, body: undefined, setHeader(name, value) { this.headers[name] = value; return this; },
    status(code) { this.statusCode = code; return this; }, json(body) { this.body = body; return this; },
    send(body) { this.body = body; return this; } };
}
function signedRequest(body, signature) {
  const raw = Buffer.from(body);
  const req = Readable.from([raw]);
  req.method = 'POST';
  req.headers = { 'x-hub-signature-256': signature || `sha256=${createHmac('sha256', env.WHATSAPP_APP_SECRET).update(raw).digest('hex')}` };
  req.url = '/api/whatsapp';
  return req;
}

test('GET verification and processor require their own secrets', async () => {
  const runtime = { processPending: async () => ({ claimed: 0, completed: 0 }) };
  const handler = createWhatsAppWebhookHandler({ env, runtime });
  const get = async (url, headers = {}) => { const res = response(); await handler({ method: 'GET', url, headers }, res); return res; };
  assert.equal((await get('/api/whatsapp?hub.mode=subscribe&hub.verify_token=verify-secret&hub.challenge=abc')).body, 'abc');
  assert.equal((await get('/api/whatsapp?hub.mode=subscribe&hub.verify_token=bad&hub.challenge=abc')).statusCode, 403);
  assert.equal((await get('/api/whatsapp?process=1')).statusCode, 401);
  assert.deepEqual((await get('/api/whatsapp?process=1', { authorization: 'Bearer cron-secret' })).body, { claimed: 0, completed: 0 });
});

test('HMAC uses exact raw bytes and rejects a changed body before storage', async () => {
  const raw = Buffer.from('{ "object" : "whatsapp_business_account" }');
  const signature = `sha256=${createHmac('sha256', env.WHATSAPP_APP_SECRET).update(raw).digest('hex')}`;
  assert.equal(verifyMetaSignature(raw, signature, env.WHATSAPP_APP_SECRET), true);
  assert.equal(verifyMetaSignature(Buffer.from(JSON.stringify(JSON.parse(raw))), signature, env.WHATSAPP_APP_SECRET), false);
  const runtime = { enqueue: () => { throw new Error('must not enqueue'); } };
  const handler = createWhatsAppWebhookHandler({ env, runtime });
  const res = response();
  await handler(signedRequest(JSON.stringify(meta([message('wamid.1')])), signature), res);
  assert.equal(res.statusCode, 403);
  assert.deepEqual(res.body, { error: 'Invalid signature' });
  const oversized = Readable.from([Buffer.alloc(262145)]);
  await assert.rejects(readRawBody(oversized), { status: 413 });
});

test('POST rejects missing secret, missing signature, and malformed signature before enqueue', async () => {
  const body = JSON.stringify(meta([message('wamid.unsigned')]));
  let enqueues = 0;
  const runtime = { enqueue: async () => { enqueues++; return []; } };
  for (const [settings, signature] of [
    [{ ...env, WHATSAPP_APP_SECRET: '' }, null],
    [env, ''],
    [env, 'sha256=not-a-valid-digest'],
  ]) {
    const request = signedRequest(body, signature ?? undefined);
    if (signature === '') delete request.headers['x-hub-signature-256'];
    const res = response();
    await createWhatsAppWebhookHandler({ env: settings, runtime })(request, res);
    assert.equal(res.statusCode, 403);
  }
  assert.equal(enqueues, 0);
});

test('signed events are durably enqueued once and STOP is revoked before 200', async () => {
  const accepted = new Set();
  const order = [];
  const runtime = {
    async enqueue(events) {
      order.push('enqueue');
      return events.filter(event => { if (accepted.has(event.provider_message_id)) return false;
        accepted.add(event.provider_message_id); return true; });
    },
    async revokeOptOut(event) { order.push(`revoke:${event.provider_message_id}`); },
    async processPending() { order.push('process'); return { claimed: 1, completed: 1 }; },
  };
  const pending = [];
  const handler = createWhatsAppWebhookHandler({ env, runtime, waitUntil: task => pending.push(task) });
  const body = JSON.stringify(meta([message('wamid.stop', 'STOP')]));
  const first = response();
  await handler(signedRequest(body), first);
  assert.equal(first.statusCode, 200);
  assert.deepEqual(order.slice(0, 2), ['enqueue', 'revoke:wamid.stop']);
  assert.equal(pending.length, 1);
  const second = response();
  await handler(signedRequest(body), second);
  assert.equal(second.statusCode, 200);
  assert.equal(order.filter(item => item === 'revoke:wamid.stop').length, 1);
  await Promise.all(pending);
});

test('status-only callbacks are acknowledged and logged without enqueuing an event', async () => {
  const payload = meta([]);
  payload.entry[0].changes[0].value.statuses = [{
    id: 'wamid.outbound', status: 'failed', recipient_id: '12025550101', timestamp: '1750000000',
    errors: [{ code: 131026, title: 'Message undeliverable', message: 'Message undeliverable',
      error_data: { details: 'Delivery failed' } }],
  }];
  const enqueued = [];
  const logs = [];
  const runtime = { async enqueue(events) { enqueued.push(...events); return []; } };
  const handler = createWhatsAppWebhookHandler({ env, runtime, logger: { log: line => logs.push(line) } });
  const res = response();

  await handler(signedRequest(JSON.stringify(payload)), res);

  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, { received: true });
  assert.deepEqual(enqueued, []);
  assert.ok(logs.some(line => line.startsWith('whatsapp-status ') && line.includes('"code":131026')));
  assert.ok(logs.includes('whatsapp-callback {"messages":0,"statuses":1}'));
});

test('callbacks containing messages and statuses log a summary and enqueue the message', async () => {
  const payload = meta([message('wamid.inbound')]);
  payload.entry[0].changes[0].value.statuses = [{ id: 'wamid.outbound', status: 'delivered' }];
  const enqueued = [];
  const logs = [];
  const runtime = { async enqueue(events) { enqueued.push(...events); return events; } };
  const handler = createWhatsAppWebhookHandler({ env, runtime, logger: { log: line => logs.push(line) } });
  const res = response();

  await handler(signedRequest(JSON.stringify(payload)), res);

  assert.equal(res.statusCode, 200);
  assert.equal(enqueued.length, 1);
  assert.equal(enqueued[0].provider_message_id, 'wamid.inbound');
  assert.ok(logs.includes('whatsapp-callback {"messages":1,"statuses":1}'));
});

test('a duplicate STOP remains actionable when the first delivery stored but failed to revoke', async () => {
  const stored = { id: 4, ...parseMetaMessages(meta([message('wamid.retry', 'STOP')]), env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID)[0],
    stop_processed_at: null };
  const supabase = {async rpc(name){assert.equal(name,'whatsapp_resolve_verified_owner');return {data:[]};}, from(name) {
    if(name==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

    assert.equal(name, 'whatsapp_inbound_events');
    return {
      upsert() { return { select: async () => ({ data: [], error: null }) }; },
      select() { return this; }, in() { return this; },
      is: async () => ({ data: [stored], error: null }),
    };
  } };
  const inbox = new SupabaseInboundInbox(supabase);
  const actionable = await inbox.enqueue([stored]);
  assert.deepEqual(actionable, [stored]);
});

test('duplicate ordinary events do not trigger another inbox continuation', async () => {
  const seen = new Set();
  let continuations = 0;
  const pending = [];
  const runtime = {
    async enqueue(events) {
      return events.filter(event => !seen.has(event.provider_message_id)
        && Boolean(seen.add(event.provider_message_id)));
    },
    async processPending() { continuations++; return { claimed: 1, completed: 1 }; },
  };
  const handler = createWhatsAppWebhookHandler({ env, runtime, waitUntil: task => pending.push(task) });
  const body = JSON.stringify(meta([message('wamid.once')]));
  for (let index = 0; index < 2; index++) {
    const res = response();
    await handler(signedRequest(body), res);
    assert.equal(res.statusCode, 200);
  }
  await Promise.all(pending);
  assert.equal(continuations, 1);
});

test('Meta parsing ignores status callbacks and other phone IDs; it never reads a claimed name', () => {
  const parsed = parseMetaMessages(meta([message('wamid.2', 'My name is Alice')]), env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID);
  assert.deepEqual(parsed.map(({ provider_message_id, sender_phone, message_text }) => ({ provider_message_id, sender_phone, message_text })),
    [{ provider_message_id: 'wamid.2', sender_phone: '+12025550101', message_text: 'My name is Alice' }]);
  const status = meta([]);
  status.entry[0].changes[0].value.statuses = [{ id: 'wamid.outbound' }];
  assert.deepEqual(parseMetaMessages(status, env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID), []);
  status.entry[0].changes[0].value.metadata.phone_number_id = 'other';
  status.entry[0].changes[0].value.messages = [message('wamid.3')];
  assert.deepEqual(parseMetaMessages(status, env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID), []);
  status.entry[0].id = 'different-waba';
  status.entry[0].changes[0].value.metadata.phone_number_id = env.WHATSAPP_PHONE_NUMBER_ID;
  assert.deepEqual(parseMetaMessages(status, env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID), []);
  assert.equal(isOptOut('Please do not message me.'), true);
  assert.equal(isOptOut('Please stop sending me messages.'), true);
  assert.equal(isOptOut('I no longer want these updates.'), true);
  assert.equal(isOptOut('stop messaging me'), true);
  assert.equal(isOptOut('Please stop messaging me!'), true);
  assert.equal(isOptOut('STOP'), true);
  assert.equal(isOptOut('unsubscribe'), true);
  assert.equal(isOptOut('cancel whatsapp'), true);
  assert.equal(isOptOut('Do not stop messaging me'), false);
  assert.equal(isOptOut('Invoice notes contain "stop messaging me"'), false);
  assert.equal(isOptOut('I do not want to pay'), false);
});

test('Meta parsing preserves signed quick reply IDs separately from their visible titles', () => {
  const selected = {id:'wamid.button',from:'12025550101',timestamp:String(Math.floor(Date.now()/1000)),type:'interactive',
    interactive:{type:'button_reply',button_reply:{id:'oab1.payload.signature',title:'Confirm'}}};
  const parsed = parseMetaMessages(meta([selected]), env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID);
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].message_type, 'interactive');
  assert.equal(parsed[0].message_text, 'Confirm');
  assert.equal(parsed[0].interactionId, 'oab1.payload.signature');
  const invalid = structuredClone(selected);
  invalid.interactive.button_reply.id = '';
  assert.deepEqual(parseMetaMessages(meta([invalid]), env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID), []);
});

test('durable inbox maps camel-case button IDs to the bounded interaction_id column', async () => {
  let upsert;
  const inbox = new SupabaseInboundInbox({ from(table) {
    assert.equal(table, 'whatsapp_inbound_events');
    return { upsert(rows, options) { upsert = { rows, options }; return { select: async () => ({data:rows,error:null})}; } };
  }});
  const input = {provider_message_id:'wamid.button',phone_number_id:env.WHATSAPP_PHONE_NUMBER_ID,
    sender_phone:'+12025550101',message_type:'interactive',message_text:'Confirm',interactionId:'oab1.payload.signature'};
  await inbox.enqueue([input]);
  assert.deepEqual(upsert.rows, [{provider_message_id:input.provider_message_id,phone_number_id:input.phone_number_id,
    sender_phone:input.sender_phone,message_type:'interactive',message_text:'Confirm',interaction_id:'oab1.payload.signature'}]);
  assert.deepEqual(upsert.options, {onConflict:'provider_message_id',ignoreDuplicates:true});
});

test('owner button references reach the owner handler separately from visible message text', async () => {
  const phone = '+12025550101';
  const event = {id:17,claim_token:'claim',attempts:1,provider_message_id:'wamid.owner-button',sender_phone:phone,
    message_type:'interactive',message_text:'Confirm',interaction_id:'oab1.payload.signature',provider_timestamp:new Date().toISOString()};
  const tables = {
    whatsapp_owner_verifications:[{workspace_id:'ws-owner',requested_by:'owner-1',verified_at:'2026-10-01T00:00:00Z',
      created_at:'2026-10-01T00:00:00Z',phone}],
    workspaces:[{id:'ws-owner',owner_id:'owner-1'}],
    workspace_members:[{workspace_id:'ws-owner',user_id:'owner-1',role:'owner'}],
    workspace_settings:[{workspace_id:'ws-owner',business_name:'Acme Studio',whatsapp_owner_phone:phone}],
    whatsapp_consents:[{workspace_id:'ws-owner',customer_id:'owner-customer',phone,revoked_at:null,consented_by:'owner-1'}],
    customers:[{id:'owner-customer',workspace_id:'ws-owner',phone,metadata:{whatsapp_owner:true}}],
    whatsapp_global_suppressions:[],whatsapp_suppressions:[],
  };
  const supabase = installVerifiedOwnerRpc({from(){throw new Error('No database read expected for an empty owner reply');}},()=>tables,{expectedPhone:phone});
  let received;
  const runtime = createInboundRuntime({supabase,conversationStore:null,env,
    inbox:{async claim(){return [event];},async complete(){}},
    outbound:{async sendTypingIndicator(){return {status:'accepted'};},async sendServiceReply(){throw new Error('No empty owner answer is sent');}},
    onOwnerMessage:async input=>{received=input;return {answer:''};}});
  assert.deepEqual(await runtime.processPending(),{claimed:1,completed:1});
  assert.equal(received.message,'Confirm');
  assert.equal(received.interactionId,'oab1.payload.signature');
});

test('owner worker forwards signed buttons and remints the same live choice on retry without persisting a token',async()=>{
  const phone='+12025550101';
  const event={id:18,claim_token:'claim',attempts:1,provider_message_id:'wamid.owner-proposal',sender_phone:phone,
    message_type:'text',message_text:'Delete invoice INV-JOHN-1',provider_timestamp:new Date().toISOString()};
  const action={id:73,version:4,workspace_id:'ws-owner',phone,consumed_at:null,
    action:{type:'owner_invoice_delete_proposal',proposalId:'77777777-7777-4777-8777-777777777777',
      expectedUpdatedAt:'2026-10-02T10:00:00Z',invoiceNumber:'INV-JOHN-1',expiresAt:new Date(Date.now()+600_000).toISOString()}};
  const tables={
    whatsapp_owner_verifications:[{workspace_id:'ws-owner',requested_by:'owner-1',verified_at:'2026-10-01T00:00:00Z',created_at:'2026-10-01T00:00:00Z',phone}],
    workspaces:[{id:'ws-owner',owner_id:'owner-1'}],workspace_members:[{workspace_id:'ws-owner',user_id:'owner-1',role:'owner'}],
    workspace_settings:[{workspace_id:'ws-owner',business_name:'Acme Studio',whatsapp_owner_phone:phone}],
    whatsapp_consents:[{workspace_id:'ws-owner',customer_id:'owner-customer',phone,revoked_at:null,consented_by:'owner-1'}],
    customers:[{id:'owner-customer',workspace_id:'ws-owner',phone,metadata:{whatsapp_owner:true}}],
    whatsapp_global_suppressions:[],whatsapp_suppressions:[],
  };
  const messages=[];const pendingRows=[action];
  const supabase={rpc:async()=>({data:null,error:null}),from(table){
    const source=table==='whatsapp_messages'?messages:table==='whatsapp_pending_actions'?pendingRows:tables[table]||[];
    const filters=[];let limit=100;
    const q={select(){return q;},eq(key,value){filters.push(row=>row[key]===value);return q;},is(key,value){filters.push(row=>(row[key]??null)===value);return q;},
      order(){return q;},limit(value){limit=value;return q;},
      upsert(value){if(!source.some(row=>row.workspace_id===value.workspace_id&&row.idempotency_key===value.idempotency_key))source.unshift(structuredClone(value));return q;},
      maybeSingle:async()=>({data:result()[0]||null}),
      then(resolve,reject){return Promise.resolve({data:result()}).then(resolve,reject);}};
    const result=()=>source.filter(row=>filters.every(filter=>filter(row))).slice(0,limit);
    return q;
  }};
  installVerifiedOwnerRpc(supabase,()=>tables,{expectedPhone:phone});
  const ownerReplyStore=createOwnerReplyStore({supabase,env,clock:()=>new Date()});
  let generated=0,deliveries=0,claims=0,deferred=0,completed=0,eventDone=false;
  const sent=[];
  const outbound={
    async sendTypingIndicator(){return {status:'accepted'};},
    async sendServiceReply(input){
      sent.push(structuredClone(input));deliveries++;
      if(deliveries===2){const row=messages.find(item=>item.idempotency_key===`reply:${event.provider_message_id}`);if(row)row.status='accepted';return {status:'accepted'};}
      return {status:'unknown',reason:'mocked graph uncertainty'};
    },
  };
  const runtime=createInboundRuntime({supabase,conversationStore:null,env,outbound,clock:()=>Date.now(),
    inbox:{async claim(){if(eventDone)return [];claims++;return [{...event,attempts:claims}];},async defer(){deferred++;},async complete(_event,error){if(!error){completed++;eventDone=true;}}},
    onOwnerMessage:async input=>{
      const saved=await ownerReplyStore.find(input);
      if(saved)return {...saved,replayed:true};
      generated++;
      const buttons=createOwnerActionButtons({scope:{workspaceId:input.workspaceId,phone:input.phone},action,env,clock:()=>new Date()});
      return ownerReplyStore.save(input,{answer:'Delete invoice INV-JOHN-1?',buttons,ownerActionRef:{pendingId:action.id,pendingVersion:action.version}});
    },logger:{info(){},warn(){},error(){}}});

  await runtime.processPending();
  assert.deepEqual(sent[0].buttons.map(({title})=>title),['Delete','Keep invoice']);
  assert.ok(deferred>0,'uncertain initial delivery leaves the owner event retryable');
  assert.deepEqual(messages[0].owner_action_ref,{pendingId:73,pendingVersion:4});
  assert.ok(!JSON.stringify(messages[0].owner_action_ref).includes(sent[0].buttons[0].id));

  await runtime.processPending();
  assert.equal(sent.length,2);
  assert.deepEqual(sent[1].buttons,sent[0].buttons,'replay remints the same ID only while the pending row is current');
  assert.equal(generated,1,'the saved owner reply is reused without rerunning the model/action');
  assert.equal(completed,1);

  await runtime.processPending();
  assert.equal(sent.length,2,'accepted replay completes the inbox event without a second outbound message');
  assert.equal(completed,1);
});

test('inbound interaction IDs are nullable and bounded in the durable event schema', async () => {
  const migrationPath = new URL('../supabase/migrations/20261003140000_whatsapp_inbound_interaction_id.sql', import.meta.url);
  let migration = null;
  try { migration = await readFile(migrationPath, 'utf8'); } catch {}
  assert.equal(typeof migration, 'string', 'the inbox needs a migration for the verified button reference');
  const db = new PGlite();
  try {
    await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
      create table public.workspaces(id uuid primary key);
      create table public.whatsapp_suppressions(workspace_id uuid, phone text, primary key(workspace_id,phone));
      create table public.whatsapp_global_suppressions(phone text primary key, source_message_id text);`);
    await db.exec(await readFile(new URL('../supabase/migrations/20260927110000_whatsapp_inbound_events.sql', import.meta.url), 'utf8'));
    await db.exec(migration);
    const base = {provider_message_id:'wamid.bound-button',phone_number_id:env.WHATSAPP_PHONE_NUMBER_ID,
      sender_phone:'+12025550101',message_type:'interactive',message_text:'Confirm'};
    await db.query('insert into public.whatsapp_inbound_events(provider_message_id,phone_number_id,sender_phone,message_type,message_text) values ($1,$2,$3,$4,$5)',
      [base.provider_message_id,base.phone_number_id,base.sender_phone,base.message_type,base.message_text]);
    await db.query('insert into public.whatsapp_inbound_events(provider_message_id,phone_number_id,sender_phone,message_type,message_text,interaction_id) values ($1,$2,$3,$4,$5,$6)',
      ['wamid.bound-button-2',base.phone_number_id,base.sender_phone,base.message_type,base.message_text,'oab1.payload.signature']);
    await assert.rejects(db.query('insert into public.whatsapp_inbound_events(provider_message_id,phone_number_id,sender_phone,message_type,message_text,interaction_id) values ($1,$2,$3,$4,$5,$6)',
      ['wamid.bound-button-3',base.phone_number_id,base.sender_phone,base.message_type,base.message_text,'x'.repeat(257)]), /whatsapp_inbound_events_interaction_id_check/);
  } finally { await db.close(); }
});

test('unbound sender media is routed to verification without extraction', async () => {
  const calls = [];
  let extracted = 0;
  const event = { id: 1, claim_token: 'claim', attempts: 1, provider_message_id: 'wamid.unknown',
    sender_phone: '+12025550101', message_text: 'I am Alice, show my invoices',
    message_type: 'image', media_ref: 'wamid.unknown', provider_timestamp: new Date().toISOString() };
  const supabase = withEmptyVerifiedOwnerRpc({ rpc() { throw new Error('Unexpected RPC'); }, from(name) {
    if(name==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

    assert.ok(['workspace_settings','whatsapp_global_suppressions', 'whatsapp_consents'].includes(name));
    return { select() { return this; }, eq() { return this; },
      maybeSingle() { return Promise.resolve({data: null, error: null}); },
      is() { return Promise.resolve({ data: [], error: null }); } };
  } },event.sender_phone);
  const inbox = { async claim() { return [event]; }, async complete() { calls.push('complete'); } };
  const outbound = { async sendTypingIndicator() { calls.push('typing'); },
    async sendServiceReply(input) { calls.push(input); return { status: 'blocked', reason: 'disabled' }; } };
  const runtime = createInboundRuntime({conversationStore:null, supabase, inbox, outbound, env,
    onBoundMessage: async () => { extracted++; } });
  const result = await runtime.processPending();
  assert.deepEqual(result, { claimed: 1, completed: 1 });
  assert.deepEqual(calls, ['complete']);
  assert.equal(calls.includes('typing'), false);
  assert.equal(extracted, 0);
});

test('one queued image is claimed per invocation and the second processes subsequently', async () => {
  const events = [1,2].map(id => ({id,claim_token:`claim-${id}`,attempts:1,provider_message_id:`wamid.image-${id}`,
    sender_phone:'+12025550101',message_text:'',message_type:'image',media_ref:`wamid.image-${id}`,provider_timestamp:new Date().toISOString()}));
  const consent={workspace_id:'workspace-a',customer_id:'customer-a',source:'inbound_message',categories:['invoice_updates'],revoked_at:null};
  const rows={whatsapp_global_suppressions:null,whatsapp_consents:[consent],whatsapp_suppressions:[],
    workspace_settings:{whatsapp_owner_attested_at:new Date().toISOString()},
    customers:{id:'customer-a',workspace_id:'workspace-a',phone:'+12025550101'}};
  const supabase=withEmptyVerifiedOwnerRpc({rpc(){},from(table){
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};
const query={select(){return query;},eq(){return query;},is(){return Promise.resolve({data:rows[table],error:null});},
    maybeSingle(){return Promise.resolve({data:rows[table],error:null});},then(resolve){return Promise.resolve({data:rows[table],error:null}).then(resolve);}};return query;}},events[0].sender_phone);
  const completed=[],extracted=[];
  const inbox={async claim(){return events.length?[events.shift()]:[];},async getMedia(event){return {bytes:Buffer.from([event.id]),mimeType:'image/png'};},
    async complete(event){completed.push(event.id);}};
  const runtime=createInboundRuntime({conversationStore:null,supabase,inbox,env,outbound:{async sendTypingIndicator(){}},
    onBoundMessage:async input=>{extracted.push(input.messageId);return ''}});
  assert.deepEqual(await runtime.processPending(),{claimed:1,completed:1});
  assert.deepEqual(events.map(event=>event.id),[2]);
  assert.deepEqual(await runtime.processPending(),{claimed:1,completed:1});
  assert.deepEqual(extracted,['wamid.image-1','wamid.image-2']);
  assert.deepEqual(completed,[1,2]);
});

test('bound customer hi webhook completes and attempts a guarded greeting service reply', async () => {
  const pending = [];
  const queued = [];
  const completed = [];
  const sends = [];
  const event = { id: 21, claim_token: 'claim', attempts: 1, provider_message_id: 'wamid.bound-hi',
    sender_phone: '+12025550101', message_text: 'hi', provider_timestamp: new Date().toISOString() };
  const consent = {workspace_id: 'workspace-a', customer_id: 'customer-a', source: 'inbound_message',
    categories: ['invoice_updates'], revoked_at: null};
  const rows = {
    whatsapp_global_suppressions: null,
    whatsapp_consents: [consent],
    whatsapp_suppressions: [],
    workspace_settings: {whatsapp_owner_attested_at: new Date().toISOString(), business_name: 'Acme Studio'},
    customers: {id: 'customer-a', workspace_id: 'workspace-a', phone: '+12025550101'},
  };
  const supabase = withEmptyVerifiedOwnerRpc({rpc() {}, from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

    const query = {
      select() { return query; }, eq() { return query; }, is() { return Promise.resolve({data: rows[table], error: null}); },
      maybeSingle() { return Promise.resolve({data: rows[table], error: null}); },
      then(resolve) { return Promise.resolve({data: rows[table], error: null}).then(resolve); },
    };
    return query;
  }},event.sender_phone);
  const inbox = {
    async enqueue(events) { queued.push(...events); return events; },
    async claim() { return queued.length ? [event] : []; },
    async complete(item, errorCode) { completed.push({item, errorCode}); },
  };
  const outbound = {async sendTypingIndicator(input) { sends.push({kind: 'typing', ...input}); }, async sendServiceReply(input) {
    neutralText(input.body);
    sends.push(input);
    return {status: 'accepted'};
  }};
  const runtime = createInboundRuntime({conversationStore:null,supabase, inbox, outbound, env,
    onBoundMessage: async ({message: text}) => (await answerWorkspaceQuestion({
      message: text, store: {query() { return []; }}, provider: null,
    })).answer});
  const handler = createWhatsAppWebhookHandler({env, runtime, waitUntil: task => pending.push(task)});
  const res = response();

  await handler(signedRequest(JSON.stringify(meta([message('wamid.bound-hi', 'hi')]))), res);
  await Promise.all(pending);

  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, {received: true});
  assert.equal(completed.length, 1);
  assert.equal(completed[0].errorCode, undefined);
  assert.equal(sends.length, 2);
  assert.deepEqual(sends[0], {kind: 'typing', messageId: 'wamid.bound-hi'});
  assert.equal(sends[1].kind, 'normal');
  assert.match(sends[1].body, /^Hi! I'm here for your Cetld account/);
});

test('typing indicator is skipped for STOP and a thrown indicator cannot fail a bound event', async () => {
  const stop = {id: 30, claim_token: 'stop-claim', attempts: 1, provider_message_id: 'wamid.stop-skip',
    sender_phone: '+12025550101', message_text: 'STOP', stop_processed_at: new Date().toISOString(),
    stop_confirmation_due: false};
  let typing = 0;
  const stopInbox = {async claim() { return [stop]; }, async complete() {}};
  const emptyOwnerLookup=withEmptyVerifiedOwnerRpc({from(){const q={select(){return q},eq(){return q},not(){return q},order(){return q},limit(){return Promise.resolve({data:[]})}};return q;}},stop.sender_phone);
  const stopRuntime = createInboundRuntime({conversationStore:null,supabase: emptyOwnerLookup, inbox: stopInbox, outbound: {
    async sendTypingIndicator() { typing++; }, async sendServiceReply() {}}, env});
  assert.deepEqual(await stopRuntime.processPending(), {claimed: 1, completed: 1});
  assert.equal(typing, 0);

  // Reuse the bound-path test's binding shape while making the UX-only call fail.
  const event = {...stop, id: 31, provider_message_id: 'wamid.typing-fails', message_text: 'hello', stop_processed_at: null};
  const consent = {workspace_id: 'workspace-a', customer_id: 'customer-a', source: 'inbound_message',
    categories: ['invoice_updates'], revoked_at: null};
  const rows = {whatsapp_global_suppressions: null, whatsapp_consents: [consent], whatsapp_suppressions: [],
    workspace_settings: {whatsapp_owner_attested_at: new Date().toISOString(), business_name: 'Acme Studio'},
    customers: {id: 'customer-a', workspace_id: 'workspace-a', phone: '+12025550101'}};
  const supabase = withEmptyVerifiedOwnerRpc({rpc() {}, from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};
 const query = {select() { return query; }, eq() { return query; },
    is: async () => ({data: rows[table], error: null}), maybeSingle: async () => ({data: rows[table], error: null}),
    then(resolve) { return Promise.resolve({data: rows[table], error: null}).then(resolve); }}; return query; }},event.sender_phone);
  let completed = false;
  const runtime = createInboundRuntime({conversationStore:null,supabase, inbox: {async claim() { return [event]; }, async complete() { completed = true; }},
    outbound: {async sendTypingIndicator() { typing++; throw new Error('Graph down'); }, async sendServiceReply() {}},
    logger: {error() {}}, onBoundMessage: async () => null, env});
  assert.deepEqual(await runtime.processPending(), {claimed: 1, completed: 1});
  assert.equal(typing, 1);
  assert.equal(completed, true);
});

test('planner fallback is sent and completed as done with bounded diagnostics and no queue retry', async () => {
  const event = {id: 23, claim_token: 'claim', attempts: 1, provider_message_id: 'wamid.planner-failure',
    sender_phone: '+12025550101', message_text: 'What do I owe?', provider_timestamp: new Date().toISOString()};
  const consent = {workspace_id: 'workspace-a', customer_id: 'customer-a', source: 'inbound_message',
    categories: ['invoice_updates'], revoked_at: null};
  const rows = {
    whatsapp_global_suppressions: null, whatsapp_consents: [consent], whatsapp_suppressions: [],
    workspace_settings: {whatsapp_owner_attested_at: new Date().toISOString(), business_name: 'Acme Studio'},
    customers: {id: 'customer-a', workspace_id: 'workspace-a', phone: '+12025550101'},
  };
  const supabase = withEmptyVerifiedOwnerRpc({rpc() {}, from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

    const query = {select() { return query; }, eq() { return query; },
      is() { return Promise.resolve({data: rows[table], error: null}); },
      maybeSingle() { return Promise.resolve({data: rows[table], error: null}); },
      then(resolve) { return Promise.resolve({data: rows[table], error: null}).then(resolve); }};
    return query;
  }},event.sender_phone);
  const completions = [];
  const sends = [];
  const inbox = {async claim() { return [event]; }, async complete(...args) { completions.push(args); }};
  const runtime = createInboundRuntime({conversationStore:null,supabase, inbox, env,
    outbound: {async sendServiceReply(input) { sends.push(input); return {status: 'accepted'}; }},
    onBoundMessage: async () => ({
      answer: "I couldn’t process that message. Send it again in a minute.",
      plannerFailure: {provider: 'AIProvider', model: 'free-model', status: 429, reason: 'provider_error'},
    })});

  assert.deepEqual(await runtime.processPending(), {claimed: 1, completed: 1});
  assert.equal(sends[0].body, "I couldn’t process that message. Send it again in a minute.");
  assert.equal(completions[0][1], 'ASSISTANT_PLANNER_FAILED');
  assert.deepEqual(JSON.parse(completions[0][2]),
    {provider: 'AIProvider', model: 'free-model', status: 429, reason: 'provider_error'});
  assert.equal(completions[0][3], false);
});

test('inbox stores terminal planner diagnostics while marking the event done', async () => {
  let update;
  const supabase = {from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

    assert.equal(table, 'whatsapp_inbound_events');
    return {update(value) { update = value; return this; }, eq() { return this; },
      then(resolve) { return Promise.resolve({data: null, error: null}).then(resolve); }};
  }};
  const inbox = new SupabaseInboundInbox(supabase);
  await inbox.complete({id: 23, claim_token: 'claim', attempts: 1, next_attempt_at: 'unchanged'},
    'ASSISTANT_PLANNER_FAILED', '{"reason":"provider_error"}', false);
  assert.equal(update.status, 'done');
  assert.ok(update.processed_at);
  assert.equal(update.next_attempt_at, 'unchanged');
  assert.equal(update.error_code, 'ASSISTANT_PLANNER_FAILED');
  assert.equal(update.error_detail, '{"reason":"provider_error"}');
});

test('deferred inbox events use bounded backoff while keeping attempts eligible for retry',async()=>{
  let update;
  const supabase={from(table){assert.equal(table,'whatsapp_inbound_events');return {update(value){update=value;return this;},
    eq(){return this;},then(resolve){return Promise.resolve({data:null,error:null}).then(resolve);}};}};
  const inbox=new SupabaseInboundInbox(supabase);const before=Date.now();
  await inbox.defer({id:31,claim_token:'claim',attempts:1,received_at:new Date(Date.now()-4*60_000).toISOString()});
  assert.equal(update.status,'pending');assert.equal(update.processed_at,null);
  assert.equal(update.attempts,0);assert.ok(Date.parse(update.next_attempt_at)>=before+16*60_000);
  assert.ok(Date.parse(update.next_attempt_at)<=Date.now()+17*60_000);
});

test('inbound processing failure log and durable event include the truncated error message', async () => {
  const logs = [];
  const event = {id: 22, claim_token: 'claim', attempts: 1, provider_message_id: 'wamid.failure',
    sender_phone: '+12025550101', message_text: 'hello'};
  let completion;
  const inbox = {async claim() { return [event]; }, async complete(...args) { completion = args; }};
  const supabase = {rpc() {}, from() { throw new Error('database lookup failed: ' + 'x'.repeat(250)); }};
  const runtime = createInboundRuntime({conversationStore:null,supabase, inbox, env,
    logger: {error(label, fields) { logs.push({label, fields}); }}});

  assert.deepEqual(await runtime.processPending(), {claimed: 1, completed: 0});
  assert.equal(logs[0].label, 'WhatsApp inbound event failed');
  assert.equal(logs[0].fields.name, 'Error');
  assert.equal(logs[0].fields.message, ('database lookup failed: ' + 'x'.repeat(250)).slice(0, 200));
  assert.equal(completion[1], 'PROCESSING_FAILED');
  assert.equal(completion[2], 'database lookup failed: ' + 'x'.repeat(250));
});

test('processing stops before the deadline and leaves the next event pending', async () => {
  const pending = [
    {id: 2, attempts: 1, provider_message_id: 'wamid.new', sender_phone: '+12025550101',
      message_text: 'STOP', stop_processed_at: new Date().toISOString(), stop_confirmation_due: false},
    {id: 1, attempts: 1, provider_message_id: 'wamid.old', sender_phone: '+12025550101',
      message_text: 'STOP', stop_processed_at: new Date().toISOString(), stop_confirmation_due: false},
  ];
  const completed = [], deferred = [];
  const times = [0, 0, 36_000];
  const inbox = {async claim(limit) { assert.equal(limit, 1); return pending.splice(0, 1); },
    async complete(event) { completed.push(event.id); },
    async defer(event) { deferred.push(event.id); pending.unshift(event); }};
  const runtime = createInboundRuntime({conversationStore:null,supabase: {}, inbox, env: {...env, WHATSAPP_PROCESS_BUDGET_MS: '40000'},
    clock: () => times.shift() ?? 36_000});

  assert.deepEqual(await runtime.processPending(), {claimed: 1, completed: 0});
  assert.deepEqual(completed, []);
  assert.deepEqual(deferred, [2]);
  assert.deepEqual(pending.map(event => event.id), [2, 1]);
});

test('a final-attempt event receives exactly one fallback and is never retried', async () => {
  const event = {id: 5, attempts: 5, provider_message_id: 'wamid.final', sender_phone: '+12025550101',
    message_text: 'slow question', received_at: new Date().toISOString()};
  const sends = [];
  const completions = [];
  let claims = 0;
  const inbox = {async claim() { claims++; return claims === 1 ? [event] : []; },
    async complete(...args) { completions.push(args); }};
  const emptyBindingSupabase=withEmptyVerifiedOwnerRpc({from(){
    const query={select(){return query;},eq(){return query;},not(){return query;},order(){return query;},limit(){return query;},
      is(){return query;},async maybeSingle(){return {data:null};},then(resolve,reject){return Promise.resolve({data:[]}).then(resolve,reject);}};
    return query;
  }},event.sender_phone);
  const runtime = createInboundRuntime({conversationStore:null,supabase: emptyBindingSupabase, inbox, env, logger: {error() {}},
    outbound: {async sendServiceReply(input) { sends.push(input); }}});

  assert.deepEqual(await runtime.processPending(), {claimed: 1, completed: 1});
  assert.equal(sends.length, 1);
  assert.equal(sends[0].body, "I couldn’t process that message. Send it again in a minute.");
  assert.equal(completions.length, 1);
  assert.deepEqual(completions[0].slice(1), ['PROCESSING_FAILED', null, false]);
});

test('verified owner failures preserve the real business identity for model-generated recovery replies',async()=>{
  for (const {attempts,recoveryReply} of [
    {attempts:1,recoveryReply:true},{attempts:5,recoveryReply:true},
    {attempts:1,recoveryReply:false},{attempts:5,recoveryReply:false},
  ]) {
  const event={id:6,attempts,provider_message_id:`wamid.owner-failure-${attempts}-${recoveryReply}`,sender_phone:'+12025550101',
    message_text:'change invoice INV-3 amount',message_type:'text',received_at:new Date().toISOString()};
  const rows={
    whatsapp_owner_verifications:[{workspace_id:'ws-owner',requested_by:'owner-1',verified_at:'2026-10-01T00:00:00Z',created_at:'2026-10-01T00:00:00Z',phone:event.sender_phone}],
    workspaces:[{id:'ws-owner',owner_id:'owner-1'}],workspace_members:[{workspace_id:'ws-owner',user_id:'owner-1',role:'owner'}],
    workspace_settings:[{workspace_id:'ws-owner',business_name:'Test Business',whatsapp_owner_phone:event.sender_phone}],
    whatsapp_global_suppressions:[],whatsapp_suppressions:[],
    whatsapp_consents:[{workspace_id:'ws-owner',customer_id:'owner-customer',phone:event.sender_phone,revoked_at:null,consented_by:'owner-1'}],
    customers:[{id:'owner-customer',workspace_id:'ws-owner',phone:event.sender_phone,metadata:{whatsapp_owner:true}}],
  };
  const supabase=installVerifiedOwnerRpc({from(table){
    const query={filters:[],select(){return query;},eq(key,value){query.filters.push(row=>row[key]===value);return query;},
      not(key,operator,value){query.filters.push(row=>operator==='is'?(row[key]??null)!==value:row[key]!==value);return query;},
      is(key,value){query.filters.push(row=>(row[key]??null)===value);return query;},order(){return query;},limit(){return query;},
      async maybeSingle(){return {data:(rows[table]||[]).filter(row=>query.filters.every(fn=>fn(row)))[0]||null};},
      then(resolve,reject){return Promise.resolve({data:(rows[table]||[]).filter(row=>query.filters.every(fn=>fn(row)))}).then(resolve,reject);}};
    return query;
  }},()=>rows,{expectedPhone:event.sender_phone});
  const completions=[];
  const inbox={async claim(){return [event];},async complete(){completions.push('complete');},
    async defer(retryEvent){completions.push(`defer:${retryEvent.id}`);}};
  const sends=[];let generated=0;
  const owner=async()=>{throw new Error('the original turn must not rerun');};
  owner.createSafeFailureReply=async input=>{generated++;assert.equal(input.workspaceId,'ws-owner');assert.equal(input.hasAttachment,false);
    return recoveryReply?'I could not finish the reply. Please check the invoice status before retrying.':null;};
  const runtime=createInboundRuntime({supabase,inbox,outbound:{async sendServiceReply(input){
    assert.equal(input.businessName,'Test Business','The outbound identity guard must accept the actual workspace business');
    sends.push(input);return {status:'accepted'};}},
    onOwnerMessage:owner,conversationStore:null,env,logger:{error(){}}});
  assert.deepEqual(await runtime.processPending(),{claimed:1,completed:recoveryReply&&attempts===5?1:0});
  assert.equal(generated,1);assert.equal(sends.length,recoveryReply?1:0);
  assert.deepEqual(completions,recoveryReply?['complete']:[`defer:${event.id}`]);
  if(!recoveryReply)continue;
  assert.equal(sends[0].body,'I could not finish the reply. Please check the invoice status before retrying.');
  assert.equal(sends[0].audience,'owner');assert.equal(sends[0].workspaceId,'ws-owner');assert.equal(sends[0].kind,'normal');
  assert.doesNotMatch(sends[0].body,/something broke|did not process/i);
  }
});

test('a failed owner-binding lookup keeps the event pending without sending a hardcoded verification reply',async()=>{
  const event={id:7,attempts:5,provider_message_id:'wamid.owner-binding-outage',sender_phone:'+12025550101',
    message_text:'Which model are you using?',message_type:'text',received_at:new Date().toISOString()};
  const calls=[];
  const runtime=createInboundRuntime({supabase:{rpc(){throw Object.assign(new Error('temporary owner database outage'),{code:'08006'});},from(){throw Object.assign(new Error('temporary owner database outage'),{code:'08006'});}},
    inbox:{async claim(){return [event];},async defer(value){calls.push(['defer',value.id]);},async complete(...args){calls.push(['complete',...args]);}},
    outbound:{async sendServiceReply(input){calls.push(['send',input]);}},conversationStore:null,env,
    onOwnerMessage:async()=>{throw new Error('Binding lookup failure must not start model tools');},logger:{error(){}}});
  assert.deepEqual(await runtime.processPending(),{claimed:1,completed:0});
  assert.deepEqual(calls,[['defer',event.id]]);
});

test('a transient failure before the final attempt remains retryable', async () => {
  const event = {id: 4, attempts: 4, provider_message_id: 'wamid.transient', sender_phone: '+12025550101',
    message_text: 'question'};
  const completions = [];
  let claimed = false;
  const inbox = {async claim() { if (claimed) return []; claimed = true; return [event]; },
    async complete(...args) { completions.push(args); }};
  const runtime = createInboundRuntime({conversationStore:null,supabase: {rpc() { throw new Error('temporary database failure'); },from() { throw new Error('temporary database failure'); }},
    inbox, env, logger: {error() {}}});

  assert.deepEqual(await runtime.processPending(), {claimed: 1, completed: 0});
  assert.deepEqual(completions[0].slice(1), ['PROCESSING_FAILED', 'temporary database failure']);
});

test('unknown STOP gets a global suppression claim before acknowledgement', async () => {
  const event = {id: 12, sender_phone: '+12025550101', message_text: 'STOP',
    provider_message_id: 'wamid.unknown-stop'};
  let marked;
  const supabase = {
    from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

      assert.equal(table, 'whatsapp_consents');
      return {select() { return this; }, eq() { return this; },
        is: async () => ({data: [], error: null})};
    },
    async rpc(name, args) {
      if(name==='whatsapp_resolve_verified_owner')return {data:[]};
      assert.equal(name, 'whatsapp_suppress_unknown_phone');
      assert.equal(args.p_phone, event.sender_phone);
      return {data: true, error: null};
    },
  };
  const runtime = createInboundRuntime({conversationStore:null,supabase, inbox: {async markStop(_event, value) { marked = value; }}, env});
  await runtime.revokeOptOut(event);
  assert.deepEqual(marked, {confirmationDue: true, workspaceId: null});
});

test('a retried STOP recovers its workspace confirmation after revocation committed', async () => {
  const event = { id: 13, sender_phone: '+12025550101', message_text: 'STOP',
    provider_message_id: 'wamid.retry-after-revoke' };
  const calls = [];
  const supabase = {
    from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

      assert.equal(table, 'whatsapp_consents');
      return {
        select() { return this; },
        eq() { return this; },
        is() { throw new Error('Revoked consent must remain visible to STOP recovery'); },
        then(resolve) { return Promise.resolve({ data: [{ workspace_id: 'workspace-a' }], error: null }).then(resolve); },
      };
    },
    async rpc(name, args) {
      if(name==='whatsapp_resolve_verified_owner')return {data:[]};
      calls.push({ name, args });
      if (name === 'whatsapp_suppress_unknown_phone') return { data: false, error: null };
      assert.equal(name, 'whatsapp_revoke_phone');
      return { data: [{ revoked: false, confirmation_due: true }], error: null };
    },
  };
  const runtime = createInboundRuntime({conversationStore:null, supabase, inbox: {
    async markStop(_event, value) { calls.push({ markStop: value }); },
  }, env });
  await runtime.revokeOptOut(event);
  assert.deepEqual(calls.at(-1), { markStop: { confirmationDue: true, workspaceId: 'workspace-a' } });
});

test('STOP installs phone-wide suppression before discovering workspace consents', async () => {
  const calls = [];
  const event = { id: 14, sender_phone: '+12025550101', message_text: 'STOP', provider_message_id: 'wamid.race' };
  const supabase = {
    from(table) {
    if(table==='whatsapp_owner_verifications')return {select(){return this},eq(){return this},not(){return this},order(){return this},limit(){return Promise.resolve({data:[]})}};

      assert.equal(table, 'whatsapp_consents');
      return { select() { return this; }, eq() { return this; },
        then(resolve) { calls.push('read-consents'); return Promise.resolve({
          data: [{ workspace_id: 'workspace-a' }], error: null,
        }).then(resolve); } };
    },
    async rpc(name) {
      if(name==='whatsapp_resolve_verified_owner')return {data:[]};
      calls.push(name);
      if (name === 'whatsapp_suppress_unknown_phone') return { data: false, error: null };
      if (name === 'whatsapp_revoke_phone') return { data: [{ revoked: true, confirmation_due: true }], error: null };
      throw new Error(`Unexpected RPC: ${name}`);
    },
  };
  const runtime = createInboundRuntime({conversationStore:null, supabase, inbox: {
    async markStop() { calls.push('mark-stop'); },
  }, env });
  await runtime.revokeOptOut(event);
  assert.deepEqual(calls, ['whatsapp_suppress_unknown_phone', 'read-consents', 'whatsapp_revoke_phone', 'mark-stop']);
});

test('Postgres inbox claims are atomic and verification replies are one-time', async () => {
  const db = new PGlite();
  try {
    await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
      create table public.workspaces(id uuid primary key);
      create table public.whatsapp_suppressions(workspace_id uuid, phone text, primary key(workspace_id,phone));
      create table public.whatsapp_global_suppressions(phone text primary key, source_message_id text);`);
    const sql = await readFile(new URL('../supabase/migrations/20260927110000_whatsapp_inbound_events.sql', import.meta.url), 'utf8');
    await db.exec(sql);
    await db.query(`insert into public.whatsapp_inbound_events(provider_message_id,phone_number_id,sender_phone,message_type,message_text)
      values ('wamid.sql','123456789','+12025550101','text','Hello')`);
    await db.exec('set role service_role');
    const claimed = (await db.query('select * from public.whatsapp_claim_inbound_events(10)')).rows;
    assert.equal(claimed.length, 1);
    assert.equal((await db.query('select * from public.whatsapp_claim_inbound_events(10)')).rows.length, 0);
    assert.equal((await db.query(`select public.whatsapp_claim_inbound_reply('wamid.sql','+12025550101','verification',null) as allowed`)).rows[0].allowed, true);
    assert.equal((await db.query(`select public.whatsapp_claim_inbound_reply('wamid.sql','+12025550101','verification',null) as allowed`)).rows[0].allowed, false);
    await db.query(`update public.whatsapp_inbound_events set status='failed',error_code='INBOUND_DEAD_LETTER',claimed_at=null,claim_token=null,received_at=now()-interval '2 hours',next_attempt_at=now()-interval '1 hour' where provider_message_id='wamid.sql'`);
    assert.equal((await db.query('select * from public.whatsapp_claim_inbound_events(10)')).rows.length, 0, 'terminal dead letters must not be claimed even after backoff expires');
    await db.exec('reset role; set role anon');
    await assert.rejects(db.query('select * from public.whatsapp_inbound_events'), /permission denied/);
  } finally { await db.close(); }
});

test('Postgres inbox claims newest events first', async () => {
  const db = new PGlite();
  try {
    await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
      create table public.workspaces(id uuid primary key);
      create table public.whatsapp_suppressions(workspace_id uuid, phone text, primary key(workspace_id,phone));
      create table public.whatsapp_global_suppressions(phone text primary key, source_message_id text);`);
    for (const migration of ['20260927110000_whatsapp_inbound_events.sql', '20260930110000_whatsapp_inbound_newest_first.sql']) {
      await db.exec(await readFile(new URL(`../supabase/migrations/${migration}`, import.meta.url), 'utf8'));
    }
    await db.query(`insert into public.whatsapp_inbound_events(provider_message_id,phone_number_id,sender_phone,message_type,message_text)
      values ('wamid.old','123456789','+12025550101','text','Old'),
             ('wamid.new','123456789','+12025550101','text','New')`);
    await db.exec('set role service_role');
    const claimed = (await db.query('select * from public.whatsapp_claim_inbound_events(1)')).rows;
    assert.equal(claimed[0].provider_message_id, 'wamid.new');
  } finally { await db.close(); }
});


test('dead-letter state uses the existing terminal failed status and lease-scoped update',async()=>{
  let update;const predicates=[];
  const supabase={from(table){assert.equal(table,'whatsapp_inbound_events');return {update(value){update=value;return this;},
    eq(key,value){predicates.push([key,value]);return this;},then(resolve){return Promise.resolve({data:null,error:null}).then(resolve);}};}};
  const inbox=new SupabaseInboundInbox(supabase);
  await inbox.deadLetter({id:45,claim_token:'current-lease'},'OWNER_REPLY_NOT_ACCEPTED');
  assert.equal(update.status,'failed');assert.equal(update.error_code,'INBOUND_DEAD_LETTER');
  assert.equal(update.error_detail,'OWNER_REPLY_NOT_ACCEPTED');assert.ok(update.processed_at);
  assert.equal(update.claim_token,null);assert.equal(update.claimed_at,null);
  assert.deepEqual(predicates,[['id',45],['claim_token','current-lease']]);
});

test('deferring a stale failed delivery becomes terminal rather than extending its backoff',async()=>{
  let update;
  const supabase={from(){return {select(){return this;},maybeSingle:async()=>({data:{reply_has_pending_intent:false}}),update(value){update=value;return this;},eq(){return this;},
    then(resolve){return Promise.resolve({data:null,error:null}).then(resolve);}};}};
  await new SupabaseInboundInbox(supabase).defer({id:46,claim_token:'lease',attempts:1,
    received_at:new Date(Date.now()-3_600_001).toISOString()},'OWNER_REPLY_NOT_ACCEPTED');
  assert.equal(update.status,'failed');assert.equal(update.error_code,'INBOUND_DEAD_LETTER');
  assert.equal(update.next_attempt_at,undefined);
});


test('fresh failed delivery records its reason so an aged retry can expire before another model call',async()=>{
  let update;
  const supabase={from(){return {update(value){update=value;return this;},eq(){return this;},
    then(resolve){return Promise.resolve({data:null,error:null}).then(resolve);}};}};
  await new SupabaseInboundInbox(supabase).defer({id:47,claim_token:'lease',attempts:1,
    received_at:new Date().toISOString()},'OWNER_REPLY_NOT_ACCEPTED','Delivery was blocked.');
  assert.equal(update.status,'pending');assert.equal(update.error_code,'OWNER_REPLY_NOT_ACCEPTED');
  assert.equal(update.error_detail,'Delivery was blocked.');
});

test('Meta contact card retains display name and phone through durable inbox text', () => {
  const rows = parseMetaMessages(meta([{...message('wamid.card'), type: 'contacts', contacts: [
    {name: {formatted_name: 'Acme Buyer'}, phones: [{phone: '+1 (415) 555-0244'}]},
  ]}]), env.WHATSAPP_PHONE_NUMBER_ID, env.WHATSAPP_WABA_ID);
  assert.equal(rows[0].message_type, 'contacts');
  assert.deepEqual(JSON.parse(rows[0].message_text), {name: 'Acme Buyer', phone: '+1 (415) 555-0244'});
});

test('owner worker forwards a durable contact card',async()=>{
  const phone = '+12025550101';
  const event = {id:17,claim_token:'claim',attempts:1,provider_message_id:'wamid.owner-button',sender_phone:phone,
    message_type:'contacts',message_text:JSON.stringify({name:'Buyer',phone:'+14155550244'}),provider_timestamp:new Date().toISOString()};
  const tables = {
    whatsapp_owner_verifications:[{workspace_id:'ws-owner',requested_by:'owner-1',verified_at:'2026-10-01T00:00:00Z',
      created_at:'2026-10-01T00:00:00Z',phone}],
    workspaces:[{id:'ws-owner',owner_id:'owner-1'}],
    workspace_members:[{workspace_id:'ws-owner',user_id:'owner-1',role:'owner'}],
    workspace_settings:[{workspace_id:'ws-owner',business_name:'Acme Studio',whatsapp_owner_phone:phone}],
    whatsapp_consents:[{workspace_id:'ws-owner',customer_id:'owner-customer',phone,revoked_at:null,consented_by:'owner-1'}],
    customers:[{id:'owner-customer',workspace_id:'ws-owner',phone,metadata:{whatsapp_owner:true}}],
    whatsapp_global_suppressions:[],whatsapp_suppressions:[],
  };
  const supabase = installVerifiedOwnerRpc({from(){throw new Error('No database read expected for an empty owner reply');}},()=>tables,{expectedPhone:phone});
  let received;
  const runtime = createInboundRuntime({supabase,conversationStore:null,env,
    inbox:{async claim(){return [event];},async complete(){}},
    outbound:{async sendTypingIndicator(){return {status:'accepted'};},async sendServiceReply(){throw new Error('No empty owner answer is sent');}},
    onOwnerMessage:async input=>{received=input;return {answer:''};}});
  assert.deepEqual(await runtime.processPending(),{claimed:1,completed:1});
  assert.deepEqual(received.contactCard,{name:'Buyer',phone:'+14155550244'});

});
