from pathlib import Path
p=Path('supabase/migrations/20261120132445_dispatch_privacy_performance.sql');s=Path('work/original-performance.sql').read_text();prefix=s[:s.index('-- Lexically unambiguous')].replace('create table app.','create table if not exists app.').replace('create function app.','create or replace function app.')
prefix=prefix.replace(" if p_value is null then return array[]::text[];end if;"," if p_value is null then return array[]::text[];end if;\n if p_kind in ('generic','party') then p_value:=app.private_invoice_normalize(p_value);end if;\n if p_kind='origin' and app.private_invoice_decode_json(p_value) is not null then return array[]::text[];end if;\n if p_kind='origin' and not app.private_invoice_has_origin(p_value) then return array[]::text[];end if;\n if p_kind in ('party','origin') and p_value ~ '^[0-9 .,;:/+()''-]+$' then return array[]::text[];end if;")
snapshot=s[s.index('create or replace function public.whatsapp_dispatch_privacy_snapshot'):]
snapshot=snapshot.replace(" revision:=sha256", " perform app.ensure_private_dispatch_index();\n revision:=sha256",1)
a=snapshot.index(' ), independent_sources as (');b=snapshot.index(' ), keys as (',a)
snapshot=snapshot[:a]+''' ), independent_parties as (
 select p.party_key k from review_parties r
 join app.private_dispatch_customer_parties p on p.party_hash=sha256(convert_to(r.k,'UTF8')) and p.party_key=r.k
 union select w.party_key from review_parties r
 join app.private_dispatch_witnesses w on w.party_hash=sha256(convert_to(r.k,'UTF8')) and w.party_key=r.k
 where not exists(select 1 from approval_words a where a.value=w.source_value)
'''+snapshot[b:]
a=snapshot.index(' with owned as materialized');b=snapshot.index(' -- Only schema-declared opaque',a)
snapshot=snapshot[:a]+''' with owned as materialized (select distinct k,sha256(convert_to(k,'UTF8')) hash from unnest(coalesce(allowed,array[]::text[]))k),
 owned_raw as materialized (
  select e.workspace_id,e.source_hash,e.term_hash,g.term from owned o join app.private_dispatch_raw_edges e on e.key_hash=o.hash and e.key=o.k
  join app.private_dispatch_global_keys g on g.workspace_id=e.workspace_id and g.source_hash=e.source_hash and g.term_hash=e.term_hash
  group by e.workspace_id,e.source_hash,e.term_hash,g.term,g.alias_count having count(*)=g.alias_count
 ) select array_agg(g.term) into terms from (select distinct on(term_hash,term) term_hash,term from app.private_dispatch_global_keys order by term_hash,term) g
 where not exists(select 1 from owned o where o.hash=g.term_hash and o.k=g.term)
 and not exists(select 1 from owned_raw r where r.term_hash=g.term_hash and r.term=g.term);
'''+snapshot[b:]
p.write_text(prefix+'\n-- Literal, reviewable replacements; no source-text rewriting at migration time.\n'+Path('work/dispatch-literal-definitions.sql').read_text()+'\n'+Path('work/dispatch-index.sql').read_text()+'\n'+snapshot)
