import os,pathlib,subprocess,time,json
p=pathlib.Path.cwd();env={'PATH':os.environ['PATH'],'TMPDIR':'/tmp','npm_config_cache':'/tmp/cetld-npm-cache'};argv=['npm','run','check:release','--','--shards=4'];started=time.time()
(p/'work/review-gate-command.json').write_text(json.dumps({'cwd':str(p),'argv':argv,'env':env,'started':started},indent=2)+'\n')
with (p/'work/review-gate.log').open('w') as log:code=subprocess.call(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'work/review-gate.exit').write_text(str(code)+'\n');(p/'work/review-gate-duration.json').write_text(json.dumps({'seconds':time.time()-started,'exit':code})+'\n');print('REVIEW_RELEASE_EXIT',code,flush=True)
raise SystemExit(code)
