-- Source membership and canonical projection are maintained on writes. A send
-- reads the deduplicated global set, never reparses or regroups every tenant.
create table if not exists app.private_dispatch_sources(
 workspace_id uuid not null references public.workspaces(id) deferrable initially deferred,
 term_hash text not null,term text not null,keys text[] not null,primary key(workspace_id,term_hash));
create index if not exists private_dispatch_sources_hash on app.private_dispatch_sources(term_hash);
create table if not exists app.private_dispatch_global_keys(
 workspace_id uuid not null,source_hash text not null,term_hash bytea not null,term text not null,alias_count integer not null default 0,primary key(workspace_id,source_hash,term_hash));
create table if not exists app.private_dispatch_raw_edges(
 workspace_id uuid not null,source_hash text not null,term_hash bytea not null,
 key_hash bytea not null,key text not null,primary key(workspace_id,source_hash,term_hash,key_hash),
 foreign key(workspace_id,source_hash,term_hash) references app.private_dispatch_global_keys(workspace_id,source_hash,term_hash) on delete cascade);
create index if not exists private_dispatch_global_order on app.private_dispatch_global_keys(term_hash);
create index if not exists private_dispatch_raw_edges_key on app.private_dispatch_raw_edges(key_hash);
create table if not exists app.private_dispatch_witnesses(
 workspace_id uuid not null,term_hash text not null,source_value text not null,party_hash bytea not null,party_key text not null,
 primary key(workspace_id,term_hash,party_hash));
create index if not exists private_dispatch_witnesses_party on app.private_dispatch_witnesses(party_hash);
create table if not exists app.private_dispatch_customer_parties(
 customer_id uuid not null references public.customers(id) on delete cascade,party_hash bytea not null,party_key text not null,
 primary key(customer_id,party_hash));
create index if not exists private_dispatch_customer_party on app.private_dispatch_customer_parties(party_hash);
create table if not exists app.private_dispatch_index_state(singleton boolean primary key default true check(singleton),revision text not null);
alter table app.private_dispatch_sources enable row level security;
alter table app.private_dispatch_global_keys enable row level security;
alter table app.private_dispatch_raw_edges enable row level security;
alter table app.private_dispatch_witnesses enable row level security;
alter table app.private_dispatch_customer_parties enable row level security;
alter table app.private_dispatch_index_state enable row level security;
revoke all on app.private_dispatch_sources,app.private_dispatch_global_keys,app.private_dispatch_raw_edges,app.private_dispatch_witnesses,app.private_dispatch_customer_parties,app.private_dispatch_index_state from public,anon,authenticated,service_role;

create or replace function app.private_dispatch_projection(p_workspace_id uuid,p_term text) returns text[]
language plpgsql volatile set search_path='' as $$
declare keys text[];
begin
 if p_term ~ '^[a-z-]+:' and p_term not like 'origin:%' then return array[p_term];end if;
 if app.private_invoice_decode_json(p_term) is not null then return array[p_term];end if;
 if p_term like 'origin:%' or p_term !~ '^[a-z-]+:' and app.private_invoice_has_origin(p_term) then
  keys:=array(select distinct k from unnest(app.private_dispatch_aliases(p_workspace_id,case when p_term like 'origin:%' then substring(p_term from 8) else p_term end,'origin',sha256(convert_to(app.private_invoice_canonical_revision(),'UTF8')),pg_try_advisory_xact_lock(1128617036,1146310723))) k
   where k ~ '^(number|number-run|date|date-range|party|party-native|party-latin|party-ref|identifier):');
  if cardinality(keys)>0 then return keys;end if;
 end if;
 return array[p_term];
end $$;

create or replace function app.fill_private_dispatch_edges() returns void
language plpgsql security definer set search_path='' as $$
begin
 -- Called for new keys only; the global raw subset has its own partial index.
 insert into app.private_dispatch_raw_edges(workspace_id,source_hash,term_hash,key_hash,key)
 select g.workspace_id,g.source_hash,g.term_hash,sha256(convert_to(k,'UTF8')),k from app.private_dispatch_global_keys g
 cross join lateral (select distinct k from app.private_invoice_term_aliases(g.term)k where k<>g.term) a
 where g.term !~ '^[a-z-]+:' and g.alias_count=-1 on conflict do nothing;
 update app.private_dispatch_global_keys g set alias_count=(select count(*) from app.private_dispatch_raw_edges e where e.workspace_id=g.workspace_id and e.source_hash=g.source_hash and e.term_hash=g.term_hash)
 where g.alias_count=-1;
end $$;
create index if not exists private_dispatch_unprepared_raw on app.private_dispatch_global_keys(term_hash) where alias_count=-1;

create or replace function app.fill_private_dispatch_witnesses() returns void
language plpgsql security definer set search_path='' as $$
begin
 insert into app.private_dispatch_witnesses(workspace_id,term_hash,source_value,party_hash,party_key)
 select s.workspace_id,s.term_hash,case when s.term like 'origin:%' then substring(s.term from 8) else s.term end,
 sha256(convert_to(k,'UTF8')),k
 from (select workspace_id,term_hash,term from app.private_dispatch_sources where term !~ '^[a-z-]+:' or term like 'origin:%')s
 cross join lateral (
  select k from unnest(app.private_dispatch_aliases(s.workspace_id,s.term,'party',sha256(convert_to(app.private_invoice_canonical_revision(),'UTF8')),pg_try_advisory_xact_lock(1128617036,1146310723)))k where s.term !~ '^[a-z-]+:'
  union select k from unnest(app.private_dispatch_aliases(s.workspace_id,case when s.term like 'origin:%' then substring(s.term from 8) else s.term end,'origin',sha256(convert_to(app.private_invoice_canonical_revision(),'UTF8')),pg_try_advisory_xact_lock(1128617036,1146310723)))k where k like 'party:%'
 )a on conflict do nothing;
end $$;
create index if not exists private_dispatch_sources_raw on app.private_dispatch_sources(term_hash) where term !~ '^[a-z-]+:' or term like 'origin:%';

create or replace function app.ensure_private_dispatch_index() returns boolean
language plpgsql security definer set search_path='' as $$
declare current_revision text:=app.private_invoice_canonical_revision();
begin
 if exists(select 1 from app.private_dispatch_index_state s where s.singleton and s.revision=current_revision) then return false;end if;
 perform pg_advisory_xact_lock(717717199);
 if exists(select 1 from app.private_dispatch_index_state s where s.singleton and s.revision=current_revision) then return false;end if;
 delete from app.private_dispatch_raw_edges;delete from app.private_dispatch_global_keys;delete from app.private_dispatch_sources;delete from app.private_dispatch_witnesses;
 insert into app.private_dispatch_sources select workspace_id,term_hash,term,app.private_dispatch_projection(workspace_id,term) from public.whatsapp_private_invoice_terms;
 insert into app.private_dispatch_global_keys(workspace_id,source_hash,term_hash,term,alias_count)
 select s.workspace_id,s.term_hash,sha256(convert_to(k,'UTF8')),k,case when k !~ '^[a-z-]+:' then -1 else 0 end
 from app.private_dispatch_sources s cross join lateral unnest(s.keys)k;
 perform app.fill_private_dispatch_edges();perform app.fill_private_dispatch_witnesses();
 delete from app.private_dispatch_customer_parties;
 insert into app.private_dispatch_customer_parties select distinct c.id,sha256(convert_to(k,'UTF8')),k from public.customers c cross join lateral app.private_invoice_party_aliases(app.private_invoice_normalize(c.name))k;
 insert into app.private_dispatch_index_state values(true,current_revision) on conflict(singleton) do update set revision=excluded.revision;
 return true;
end $$;

create or replace function app.maintain_private_dispatch_index() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if app.ensure_private_dispatch_index() then return null;end if;
 if tg_op in ('DELETE','UPDATE') then
  delete from app.private_dispatch_raw_edges g using dispatch_old_terms o where g.workspace_id=o.workspace_id and g.source_hash=o.term_hash;
  delete from app.private_dispatch_global_keys g using dispatch_old_terms o where g.workspace_id=o.workspace_id and g.source_hash=o.term_hash;
  delete from app.private_dispatch_sources g using dispatch_old_terms o where g.workspace_id=o.workspace_id and g.term_hash=o.term_hash;
  delete from app.private_dispatch_witnesses g using dispatch_old_terms o where g.workspace_id=o.workspace_id and g.term_hash=o.term_hash;
 end if;
 if tg_op in ('INSERT','UPDATE') then
  with added as (insert into app.private_dispatch_sources select workspace_id,term_hash,term,app.private_dispatch_projection(workspace_id,term) from dispatch_new_terms
    on conflict do nothing returning workspace_id,term_hash,keys)
  insert into app.private_dispatch_global_keys(workspace_id,source_hash,term_hash,term,alias_count)
  select r.workspace_id,r.term_hash,sha256(convert_to(k,'UTF8')),k,case when k !~ '^[a-z-]+:' then -1 else 0 end from added r cross join lateral unnest(r.keys)k;
  perform app.fill_private_dispatch_edges();
  -- Witnesses are needed only for new raw sources, not all retained rows.
  insert into app.private_dispatch_witnesses
  select distinct n.workspace_id,n.term_hash,case when n.term like 'origin:%' then substring(n.term from 8) else n.term end,sha256(convert_to(k,'UTF8')),k
  from dispatch_new_terms n cross join lateral (
   select k from unnest(app.private_dispatch_aliases(n.workspace_id,n.term,'party',sha256(convert_to(app.private_invoice_canonical_revision(),'UTF8')),pg_try_advisory_xact_lock(1128617036,1146310723)))k where n.term !~ '^[a-z-]+:'
   union select k from unnest(app.private_dispatch_aliases(n.workspace_id,case when n.term like 'origin:%' then substring(n.term from 8) else n.term end,'origin',sha256(convert_to(app.private_invoice_canonical_revision(),'UTF8')),pg_try_advisory_xact_lock(1128617036,1146310723)))k where k like 'party:%'
  )a where n.term !~ '^[a-z-]+:' or n.term like 'origin:%' on conflict do nothing;
 end if;
 return null;
end $$;
create or replace function app.truncate_private_dispatch_index() returns trigger language plpgsql security definer set search_path='' as $$begin
 truncate app.private_dispatch_sources,app.private_dispatch_global_keys,app.private_dispatch_raw_edges,app.private_dispatch_witnesses;return null;end $$;
create or replace function app.maintain_private_dispatch_customer() returns trigger language plpgsql security definer set search_path='' as $$begin
 delete from app.private_dispatch_customer_parties where customer_id=new.id;
 insert into app.private_dispatch_customer_parties select new.id,sha256(convert_to(k,'UTF8')),k from app.private_invoice_party_aliases(app.private_invoice_normalize(new.name))k on conflict do nothing;return new;end $$;
drop trigger if exists private_dispatch_insert on public.whatsapp_private_invoice_terms;
create trigger private_dispatch_insert after insert on public.whatsapp_private_invoice_terms referencing new table as dispatch_new_terms for each statement execute function app.maintain_private_dispatch_index();
drop trigger if exists private_dispatch_delete on public.whatsapp_private_invoice_terms;
create trigger private_dispatch_delete after delete on public.whatsapp_private_invoice_terms referencing old table as dispatch_old_terms for each statement execute function app.maintain_private_dispatch_index();
drop trigger if exists private_dispatch_update on public.whatsapp_private_invoice_terms;
create trigger private_dispatch_update after update on public.whatsapp_private_invoice_terms referencing old table as dispatch_old_terms new table as dispatch_new_terms for each statement execute function app.maintain_private_dispatch_index();
drop trigger if exists private_dispatch_truncate on public.whatsapp_private_invoice_terms;
create trigger private_dispatch_truncate after truncate on public.whatsapp_private_invoice_terms for each statement execute function app.truncate_private_dispatch_index();
drop trigger if exists private_dispatch_customer on public.customers;
create trigger private_dispatch_customer after insert or update of name on public.customers for each row execute function app.maintain_private_dispatch_customer();
revoke all on function app.private_dispatch_projection(uuid,text),app.fill_private_dispatch_edges(),app.fill_private_dispatch_witnesses(),app.ensure_private_dispatch_index(),app.maintain_private_dispatch_index(),app.truncate_private_dispatch_index(),app.maintain_private_dispatch_customer() from public,anon,authenticated,service_role;
select app.ensure_private_dispatch_index();
