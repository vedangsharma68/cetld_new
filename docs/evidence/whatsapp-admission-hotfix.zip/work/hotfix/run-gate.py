import os,subprocess,json,time,pathlib
p=pathlib.Path.cwd(); env={'PATH':os.environ['PATH'],'TMPDIR':'/tmp','npm_config_cache':str(p/'work/hotfix/npm-cache')}
command=['npm','run','check:release','--','--shards=4']
(p/'work/hotfix/gate-command.json').write_text(json.dumps({'argv':command,'env':env,'cwd':str(p)},indent=2)+'\n')
start=time.time()
with (p/'work/hotfix/gate.log').open('w') as log:code=subprocess.call(command,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'work/hotfix/gate-result.json').write_text(json.dumps({'exit':code,'seconds':time.time()-start})+'\n')
print('GATE_RESULT',code,flush=True)
