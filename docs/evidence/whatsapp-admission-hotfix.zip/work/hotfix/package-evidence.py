import hashlib,json,pathlib,re,subprocess,zipfile
p=pathlib.Path.cwd();w=p/'work/hotfix';result=json.loads((w/'gate-result.json').read_text());assert result['exit']==0
log=(w/'gate.log').read_text();assert 'Owner chat release gate passed.' in log
shards=[]
for part in log.split('RELEASE_SHARD_START ')[1:]:
 body=part.split('RELEASE_SHARD_EXIT ')[0];shard=int(body.split()[0]);row={'shard':shard}
 for key in ['tests','pass','fail','skipped']:
  matches=re.findall(r'^[ℹ#] '+key+r' (\d+)\s*$',body,re.M);assert matches,(shard,key);row[key]=int(matches[-1])
 assert row['fail']==0;shards.append(row)
assert len(shards)==4
result.update(shards=shards,total={k:sum(x[k] for x in shards) for k in ['tests','pass','fail','skipped']},typecheck=True,frontendBuild=True,productionBatteryScenarios=43,offlineRoute={'pass':2,'fail':0})
(w/'verified-results.json').write_text(json.dumps(result,indent=2)+'\n')
source=subprocess.check_output(['git','diff','--name-only','0f72c6c','HEAD'],text=True).splitlines()
assert all(pathlib.Path(f).is_file() for f in source)
preservation=json.loads((w/'preservation.json').read_text())
report=pathlib.Path('docs/whatsapp-admission-hotfix.md');report.write_text((w/'report-draft.md').read_text().rstrip()+'\n\n## Completed clean release gate\n\n`npm run check:release -- --shards=4`, clean unset environment, exit 0.\n\n| Shard | Tests | Pass | Fail | Existing skips |\n|---|---:|---:|---:|---:|\n'+''.join('| '+str(x['shard'])+' | '+' | '.join(str(x[k]) for k in ['tests','pass','fail','skipped'])+' |\n' for x in shards)+'| Total | '+' | '.join(str(result['total'][k]) for k in ['tests','pass','fail','skipped'])+' |\n\nTypecheck, the 43-scenario production battery, offline-route child 2/2, and frontend build/postcheck passed. '+str(preservation['unchangedTestsFiles'])+' pre-existing tests-directory files remain byte-identical. No new skips or timeout/budget changes.\n\nFull logs, commands, regression source, per-file pins and historical interrupted-run provenance are in `docs/evidence/whatsapp-admission-hotfix.zip`; its SHA-256 sidecar is adjacent.\n')
files=source+[str(report)]
pins={'base':subprocess.check_output(['git','rev-parse','0f72c6c'],text=True).strip(),'testedSourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceSHA256':{f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest() for f in files},'preservation':preservation,'verification':result,'productionEffects':False,'executionPermissions':'Localhost/subprocess support enabled; clean environment contains no production credentials.'}
evidence=p/'docs/evidence';evidence.mkdir(exist_ok=True)
pinpath=evidence/'whatsapp-admission-hotfix-pins.json';pinpath.write_text(json.dumps(pins,indent=2)+'\n')
artifacts=[str(pinpath.relative_to(p))]+[str(f.relative_to(p)) for f in w.iterdir() if f.is_file() and f.suffix in ['.log','.json','.py','.mjs']]
items=sorted(set(files+artifacts));manifest={'files':[{'path':f,'bytes':pathlib.Path(f).stat().st_size,'sha256':hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()} for f in items]}
archive=evidence/'whatsapp-admission-hotfix.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in items:z.write(f,f)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
sha=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix('.zip.sha256').write_text(sha+'  '+archive.name+'\n')
with zipfile.ZipFile(archive) as z:
 for f in manifest['files']:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
print(json.dumps({'total':result['total'],'archive':str(archive.relative_to(p)),'sha256':sha,'members':len(items)+1}))
