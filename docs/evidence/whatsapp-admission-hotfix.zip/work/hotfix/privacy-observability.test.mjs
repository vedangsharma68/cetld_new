import test from 'node:test';import assert from 'node:assert/strict';
import {fixture} from '../../tests/fixtures/private-invoice.mjs';import {createInboundRuntime} from '../../automation/whatsapp/cloud-inbound.mjs';
test('terminal privacy decisions emit correlation/rule codes without matched content or transport',async()=>{
 const f=await fixture();try{
  const id='wamid.safe-diagnostic',privateAmount=927461,body='send '+privateAmount+' today',logs=[];let sends=0;
  const owner=(await f.db.query('insert into auth.users(id) values(gen_random_uuid()) returning id')).rows[0].id;
  const foreign=(await f.db.query("insert into workspaces(owner_id,name,slug) values($1,'Foreign workspace','foreign-observability') returning id",[owner])).rows[0].id;
  await f.db.query('select app.retain_private_invoice_terms($1,$2)',[foreign,{total:privateAmount}]);
  await f.db.query("insert into whatsapp_inbound_events(provider_message_id,phone_number_id,sender_phone,message_type,message_text,provider_timestamp,status) values($1,'123456',$2,'text','Hello',now(),'pending')",[id,f.scope.phone]);
  const r=createInboundRuntime({supabase:f.supabase,env:{WHATSAPP_OUTBOUND_ENABLED:'true',WHATSAPP_COMMERCIAL_OUTBOUND_ENABLED:'true',WHATSAPP_ACCESS_TOKEN:'fixture',WHATSAPP_PHONE_NUMBER_ID:'123456',WHATSAPP_GRAPH_API_VERSION:'v24.0'},logger:{info(){},warn:(...a)=>logs.push(a),error:(...a)=>logs.push(a)},onOwnerMessage:async()=>({answer:body}),fetchImpl:async(_,init)=>{const p=JSON.parse(init.body);if(p.status==='read')return Response.json({success:true});sends++;return Response.json({messages:[{id:'never'}]});}});
  await r.processPending();assert.equal(sends,0);
  const verdict=logs.flat().find(x=>x?.event==='whatsapp_privacy_verdict');assert.equal(verdict.category,'uncertified_value');assert.equal(verdict.retryable,false);assert.match(verdict.correlationId,/^[a-f0-9]{64}$/);
  assert.ok(!JSON.stringify(logs).includes(String(privateAmount)));assert.ok(!JSON.stringify(logs).includes(body));
  assert.equal((await f.db.query('select d.status from app.whatsapp_service_deliveries d join whatsapp_inbound_events e on e.id=d.event_id where e.provider_message_id=$1',[id])).rows[0].status,'blocked');
  assert.equal((await f.db.query("select status from whatsapp_messages where idempotency_key=$1",['reply:'+id])).rows[0].status,'blocked');
 }finally{await f.close();}
});
