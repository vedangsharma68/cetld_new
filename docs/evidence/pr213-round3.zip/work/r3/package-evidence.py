import pathlib,subprocess,json,hashlib,zipfile,re
p=pathlib.Path.cwd();base='fc393eebcad5f999efb92375cd8c9f91c88f8dd7';root=p/'work/r3';digest=lambda b:hashlib.sha256(b).hexdigest()
assert (root/'gate.exit').read_text().strip()=='0'
log=(root/'gate.log').read_text();assert 'Owner chat release gate passed.' in log and '> node scripts/build-frontend.mjs' in log
for f,h in json.loads((root/'tested-source-pins.json').read_text()).items():assert digest((p/f).read_bytes())==h,'Source drift: '+f
shards=[]
for i in range(4):
 body=log.split('RELEASE_SHARD_START '+str(i)+' 4',1)[1].split('RELEASE_SHARD_EXIT '+str(i)+' 0',1)[0]
 row={'shard':i,'exit':0}
 for name in ['tests','pass','fail','skipped']:
  v=re.findall(r'^ℹ '+name+r' (\d+)$',body,re.M);assert len(v)==1,(i,name,v);row[name]=int(v[0])
 shards.append(row)
results={'shards':shards,'total':{n:sum(r[n] for r in shards) for n in ['tests','pass','fail','skipped']},'exit':0,'duration':json.loads((root/'gate-duration.json').read_text()),'timings':[],'productionBattery43':'43 scenario' in log,'typecheck':'> tsc --noEmit' in log,'frontendBuild':'> node scripts/build-frontend.mjs' in log}
for line in log.splitlines():
 if any(k in line for k in ['"globalRows":','"invoices":1001','"denseSourceRows":','"firstBuildMs":']):results['timings'].append(json.loads(line[line.index('{'):]))
assert results['total']['fail']==0 and all(results[k] for k in ['productionBattery43','typecheck','frontendBuild'])
(root/'final-results.json').write_text(json.dumps(results,indent=2)+'\n')
changed=set(subprocess.check_output(['git','diff','--name-only',base],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
changed={f for f in changed if not f.startswith(('docs/evidence/','work/')) and (p/f).is_file()}
pins={f:digest((p/f).read_bytes()) for f in sorted(changed)}
immutable='supabase/migrations/20261028030825_offline_invoice_review_corrections.sql';assert digest((p/immutable).read_bytes())=='841034b20e9faee511248ed8ee2ebd7becab6c082003abee5489889f027c118d'
metadata={'reviewedBase':base,'sourceSHA256':pins,'results':results,'immutableMigration':{'path':immutable,'sha256':digest((p/immutable).read_bytes())},'authoritativeRun':'work/r3/gate.log with its recorded exit0; other logs are development provenance, not final run claims','productionEffects':False}
meta=(json.dumps(metadata,indent=2)+'\n').encode();(p/'docs/evidence/pr213-round3-pins.json').write_bytes(meta)
files={f:(p/f).read_bytes() for f in sorted(changed)};files['PINNED-SOURCES.json']=meta
for f in sorted(root.iterdir()):
 if f.is_file() and f.suffix in ['.log','.json','.exit','.py'] and f.name!='direct-baseline.log':files[str(f.relative_to(p))]=f.read_bytes()
manifest={f:{'bytes':len(b),'sha256':digest(b)} for f,b in sorted(files.items())};files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=p/'docs/evidence/pr213-round3.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f,b in sorted(files.items()):z.writestr(f,b)
sha=digest(archive.read_bytes());archive.with_suffix('.zip.sha256').write_text(sha+'  '+archive.name+'\n')
with zipfile.ZipFile(archive) as z:
 for f,m in manifest.items():assert digest(z.read(f))==m['sha256'] and len(z.read(f))==m['bytes'],f
print(json.dumps({'archive':str(archive.relative_to(p)),'sha256':sha,'members':len(files),'sourceFiles':len(pins),'results':results['total']}))
